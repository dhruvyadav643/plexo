import type { Writable } from 'node:stream'
import type { ClientRequest, IncomingMessage } from 'node:http'
import { URL } from 'node:url'
import { asConnectionError, type StreamConnection } from '../network/routes'
import type { BrowserContext } from '../../shared/types'
import { testKnobs } from '../testKnobs'
import { requestHeaders } from './browserContext'
import { compareVersion, type FileVersion, type VersionCheck } from './fileVersion'

export interface ChunkDownloadOptions {
  url: string
  browser?: BrowserContext
  rangeStart: number
  /** null = open-ended range, download to end of file. */
  rangeEnd: number | null
  /** The server doesn't take range requests, so ask for the whole file without a Range header
   * (only valid from byte 0). Some servers refuse any Range with 403 (#131). */
  wholeFile?: boolean
  /** The stream's connection, through the network it's bound to. */
  connection: StreamConnection
  createDestination: () => Writable
  /** Network bytes received, before destination backpressure or disk writes. */
  onNetworkProgress: (bytesReceivedThisRun: number) => void
  /** Bytes accepted by the destination writer; safe to include in resumable progress. */
  onProgress: (bytesDownloadedThisRun: number) => void
  /** Whether delivered bytes wait on the disk: its writer is full, or writing the last bytes. */
  onWriteWait?: (waiting: boolean) => void
  signal: AbortSignal
  /** The version the download started on, plus any confirmed to serve identical bytes. */
  acceptedVersions: FileVersion[]
  /** Called once the server has answered with usable headers: how long that took, and whether
   * the request went out on a connection an earlier one had already warmed up. */
  onResponse?: (info: { ttfbMs: number; reusedSocket: boolean }) => void
  /** Told of every body byte received; answers how many ms to stop reading for (see Limits). */
  throttle?: (bytes: number) => number
  /** How many bytes of the range are still wanted, from rangeStart: it can drop while the
   * request runs, when another stream takes over the rest of the range (see scheduler.ts). Once
   * that many are in, the rest of the body is left unread and the request ends as if the range
   * had ended there. */
  wanted?: () => number
}

/** A response whose version doesn't match the download's. Nothing from it was written; the
 * caller decides whether it's a new file (fail) or the same bytes under another label (accept). */
export class RemoteChangedError extends Error {
  constructor(
    readonly check: Exclude<VersionCheck, { kind: 'same' }>,
    readonly seen: FileVersion
  ) {
    super(
      `The file on the server changed during the download (${check.detail}). Start the download over.`
    )
  }
}

/** The server answered with a status that isn't the range asked for. */
export class HttpStatusError extends Error {
  constructor(
    readonly status: number,
    /** How long the server asked to be left alone (Retry-After), if it said. */
    readonly retryAfterMs: number | null
  ) {
    super(`Unexpected status ${status} for range request`)
  }

  /** A server that is busy, briefly broken or limiting requests: worth waiting out, not a sign
   * that asking again will never work. The statuses curl's --retry treats as transient. */
  get transient(): boolean {
    return [408, 429, 500, 502, 503, 504].includes(this.status)
  }
}

/** Retry-After (RFC 9110 §10.2.3), in seconds or as an HTTP date, as milliseconds from now. */
export function retryAfterMs(value: string | undefined, now = Date.now()): number | null {
  if (!value) return null
  const trimmed = value.trim()
  if (/^\d+$/.test(trimmed)) return Number(trimmed) * 1000
  const at = Date.parse(trimmed)
  return Number.isNaN(at) ? null : Math.max(0, at - now)
}

// A server that accepts the connection and then goes silent (no data, no
// error, no close) would otherwise hang the chunk forever with no way to
// detect or retry it.
const STALL_TIMEOUT_MS = testKnobs.stallTimeoutMs

// Only the initial probe resolves redirects today — if a CDN reissues a
// redirect mid-download (e.g. a signed URL rotates), a chunk needs to be
// able to follow it too instead of failing outright.
const MAX_REDIRECTS = 5

// A socket hands over what it has as it arrives — often 16 KiB at a time — and each write is a
// trip through libuv's thread pool and back to the main thread. Body chunks are gathered into
// one write (one writev) of up to WRITE_COALESCE_BYTES, and held no longer than
// WRITE_COALESCE_MS, so a slow connection's bytes still reach the disk (and count) promptly.
// A batch in flight plus the next one gathering stay under half the writer's buffer
// (downloadFile.ts): a full writer still means the disk is behind (see DiskWatch), not batching.
const WRITE_COALESCE_BYTES = 128 * 1024
const WRITE_COALESCE_MS = 20

interface ServedRange {
  start: number
  end: number
  /** null when the server sent `*`. */
  total: number | null
}

/** Parses `Content-Range: bytes <start>-<end>/<total>`. Returns null if it isn't in that form. */
function parseContentRange(value: string | string[] | undefined): ServedRange | null {
  const raw = Array.isArray(value) ? value[0] : value
  if (!raw) return null
  const match = /^\s*bytes\s+(\d+)-(\d+)\/(\d+|\*)\s*$/i.exec(raw)
  if (!match) return null
  const start = Number(match[1])
  const end = Number(match[2])
  if (!Number.isFinite(start) || !Number.isFinite(end) || end < start) return null
  return { start, end, total: match[3] === '*' ? null : Number(match[3]) }
}

function header(res: IncomingMessage, name: string): string | undefined {
  const value = res.headers[name]
  return Array.isArray(value) ? value[0] : value
}

/** The version a response says it's from. A 206 states the file's total size in
 * Content-Range; a 200 is the whole file, so its length is the size. */
function versionOf(res: IncomingMessage, served: ServedRange | null): FileVersion {
  const length = header(res, 'content-length')
  return {
    etag: header(res, 'etag') ?? null,
    lastModified: header(res, 'last-modified') ?? null,
    totalBytes: served?.total ?? (res.statusCode === 200 && length ? Number(length) : 0)
  }
}

/**
 * Downloads a single byte range of a URL, bound to one network interface, into a supplied writer.
 *
 * Resolving means the *entire* requested range was written, and nothing else was:
 * a chunk's bytes land at a fixed offset in the staged file, so a response
 * that is short, starts somewhere else, or overruns the range would corrupt the
 * output rather than just this chunk. Every one of those is a rejection, which
 * puts the block back on the queue for a retry instead of marking it done.
 */
export function downloadChunk(options: ChunkDownloadOptions): Promise<void> {
  const {
    url,
    browser,
    rangeStart,
    rangeEnd,
    wholeFile = false,
    connection,
    createDestination,
    onNetworkProgress,
    onProgress,
    signal,
    acceptedVersions,
    onResponse,
    throttle,
    onWriteWait,
    wanted
  } = options

  return new Promise((resolve, reject) => {
    if (signal.aborted) {
      reject(new DOMException('Aborted', 'AbortError'))
      return
    }

    const expectedBytes = rangeEnd === null ? null : rangeEnd - rangeStart + 1

    let bytesDownloaded = 0
    let settled = false
    let currentReq: ClientRequest | null = null
    let currentFileStream: Writable | null = null
    let stallWatchdog: NodeJS.Timeout | null = null
    let coalesceTimer: NodeJS.Timeout | null = null

    const clearWatchdog = (): void => {
      if (stallWatchdog) {
        clearTimeout(stallWatchdog)
        stallWatchdog = null
      }
    }

    const resetWatchdog = (): void => {
      clearWatchdog()
      stallWatchdog = setTimeout(() => {
        fail(asConnectionError(new Error('Connection stalled: no response from server')))
      }, STALL_TIMEOUT_MS)
    }

    const finish = (fn: () => void): void => {
      if (settled) return
      settled = true
      clearWatchdog()
      if (coalesceTimer) clearTimeout(coalesceTimer)
      signal.removeEventListener('abort', onAbort)
      fn()
    }

    const fail = (error: Error): void =>
      finish(() => {
        currentReq?.destroy()
        // Closing the writer matters twice over: an abandoned stream holds
        // its descriptor for the life of the process (a paused-and-resumed
        // download, or a chunk that retries a few times, leaks one per
        // attempt until the process hits its open-file limit), and its
        // buffered writes would otherwise land after a retry has started.
        // It is closed by writing out what it holds, unless writing is what
        // failed: every buffered byte was checked against the range before it
        // was queued, so it counts like any other, and whoever takes the block
        // next resumes after it instead of fetching it again.
        const stream = currentFileStream
        if (stream && !stream.closed) {
          stream.once('close', () => reject(error))
          if (stream.errored) stream.destroy()
          else stream.end()
        } else {
          reject(error)
        }
      })

    const onAbort = (): void => fail(new DOMException('Aborted', 'AbortError'))
    signal.addEventListener('abort', onAbort)

    // The whole file from the start needs no Range at all — and an empty file would answer
    // `bytes=0-` with 416, since it has no byte 0 to start from.
    const range: Record<string, string> =
      !(wholeFile && rangeStart === 0) && (rangeStart > 0 || rangeEnd !== null)
        ? { Range: rangeEnd === null ? `bytes=${rangeStart}-` : `bytes=${rangeStart}-${rangeEnd}` }
        : {}

    const attempt = (targetUrl: URL, redirectsLeft: number): void => {
      void connection
        .request(targetUrl, { ...requestHeaders(targetUrl, browser), ...range }, signal)
        .then(({ req, res, sentAt }) => {
          if (settled) {
            req.destroy()
            return
          }
          currentReq = req
          // The connection dropping mid-answer; one the server answered wrongly fails below. Once
          // the body has ended — or been cut short on purpose — only the writer can still fail.
          let bodyEnded = false
          const dropped = (error: Error): void => {
            if (!bodyEnded) fail(asConnectionError(error))
          }
          req.on('error', dropped)
          const status = res.statusCode ?? 0

          if (status >= 300 && status < 400) {
            res.resume()
            if (!res.headers.location || redirectsLeft <= 0) {
              fail(new Error('Too many redirects for range request'))
              return
            }
            attempt(new URL(res.headers.location, targetUrl), redirectsLeft - 1)
            return
          }

          // A 200 is only correct here if we asked from byte 0 — otherwise the
          // server ignored our Range and we'd silently write the wrong bytes
          // into this chunk's slot. When the range is also bounded, the
          // length check at the end of the body is what confirms the server
          // sent this chunk rather than the whole file.
          const isValidFullBody = status === 200 && rangeStart === 0
          if (status !== 206 && !isValidFullBody) {
            fail(new HttpStatusError(status, retryAfterMs(header(res, 'retry-after'))))
            res.resume()
            return
          }

          // Each range is fetched separately, so a file republished mid-download would otherwise
          // be stitched together from two versions and still pass every length check.
          const served = parseContentRange(res.headers['content-range'])
          const seen = versionOf(res, served)
          const check = compareVersion(acceptedVersions, seen)
          if (check.kind !== 'same') {
            fail(new RemoteChangedError(check, seen))
            res.resume()
            return
          }

          // A 206 says where in the file these bytes belong — check it lines up
          // with what we asked for before writing any of them.
          if (status === 206) {
            if (!served) {
              fail(new Error('Server sent a 206 without a usable Content-Range header'))
              res.resume()
              return
            }
            if (served.start !== rangeStart) {
              fail(
                new Error(
                  `Server returned the wrong range: asked for byte ${rangeStart}, got ${served.start}`
                )
              )
              res.resume()
              return
            }
            // Some hosts name the end of the file in Content-Range while sending Content-Length
            // bytes for the range. The header alone would look like an overrun; the length says
            // the body is exactly what we asked for, so take it rather than fail every block.
            const declared = Number(header(res, 'content-length') ?? NaN)
            if (
              rangeEnd !== null &&
              served.end > rangeEnd &&
              !(Number.isFinite(declared) && declared === expectedBytes)
            ) {
              fail(
                new Error(
                  `Server returned more than the requested range: through byte ${served.end}, asked through ${rangeEnd}`
                )
              )
              res.resume()
              return
            }
          }

          onResponse?.({ ttfbMs: Date.now() - sentAt, reusedSocket: req.reusedSocket })

          const fileStream = createDestination()
          currentFileStream = fileStream

          res.on('error', dropped)
          fileStream.on('error', fail)

          // Arm watchdog for incoming body bytes — drops and retries if the server sends
          // headers then freezes, or goes silent mid-stream.
          resetWatchdog()

          // Reading stops while the disk catches up or a speed limit says to wait, and goes on
          // once neither holds it. Neither says anything about the network: the watchdog stops
          // until then.
          let holds = 0
          const hold = (): void => {
            if (holds++ === 0) {
              clearWatchdog()
              res.pause()
            }
          }
          const release = (): void => {
            if (--holds > 0 || settled || bodyEnded) return
            resetWatchdog()
            res.resume()
          }

          // Corked between flushes; see WRITE_COALESCE_BYTES. end() uncorks, so the end and
          // fail paths write out what is gathered like any other buffered bytes.
          let corked = false
          let gathered = 0
          const flushWrites = (): void => {
            if (!corked) return
            corked = false
            gathered = 0
            fileStream.uncork()
          }
          const gather = (): void => {
            if (corked) return
            corked = true
            fileStream.cork()
            // One timer, re-armed per batch; firing with nothing gathered does nothing.
            if (coalesceTimer) coalesceTimer.refresh()
            else coalesceTimer = setTimeout(() => flushWrites(), WRITE_COALESCE_MS)
          }

          const endBody = (): void => {
            bodyEnded = true
            clearWatchdog()
            flushWrites()
            // Held until its last bytes are written; closing the file isn't the disk falling
            // behind.
            onWriteWait?.(true)
            fileStream.once('finish', () => onWriteWait?.(false))
            // Windows cannot reliably reopen/remove a file until its handle closes.
            fileStream.once('close', () => finish(resolve))
            fileStream.end()
          }

          // Written by hand rather than piped so an overlong body can be cut off
          // at the range boundary: an overlong response could overwrite the next block.
          res.on('data', (chunk: Buffer) => {
            if (settled || bodyEnded) return
            resetWatchdog()

            const remaining =
              expectedBytes === null ? chunk.length : expectedBytes - bytesDownloaded
            // Bytes past what is still wanted aren't an overlong body: they are left unread.
            const keep = Math.min(remaining, (wanted?.() ?? Infinity) - bytesDownloaded)
            const usable = chunk.length <= keep ? chunk : chunk.subarray(0, Math.max(keep, 0))

            if (usable.length > 0) {
              bytesDownloaded += usable.length
              const progress = bytesDownloaded
              onNetworkProgress(progress)
              gather()
              // Every write's callback comes before the writer closes, and this only
              // settles once it has, stopped or not.
              const accepted = fileStream.write(usable, (error) => {
                if (error) fail(error)
                else onProgress(progress)
              })
              gathered += usable.length
              // A full writer only drains once what it holds is let go.
              if (!accepted || gathered >= WRITE_COALESCE_BYTES) flushWrites()
              if (!accepted) {
                onWriteWait?.(true)
                hold()
                fileStream.once('drain', () => {
                  onWriteWait?.(bodyEnded)
                  release()
                })
              }
              const wait = throttle?.(usable.length) ?? 0
              if (wait > 0) {
                flushWrites()
                hold()
                setTimeout(release, wait)
              }
            }

            const rangeLeft = expectedBytes === null ? Infinity : expectedBytes - bytesDownloaded
            if (wanted && rangeLeft > 0 && bytesDownloaded >= wanted()) {
              // The rest of the range is another stream's now. The socket still has it coming,
              // so it can't carry another request: it goes, and the writer finishes as at the
              // end of a body.
              endBody()
              currentReq?.destroy()
            } else if (usable.length < chunk.length) {
              fail(new Error('Server sent more data than the requested range'))
            }
          })

          res.on('end', () => {
            if (settled || bodyEnded) return
            clearWatchdog()
            if (expectedBytes !== null && bytesDownloaded !== expectedBytes) {
              fail(
                new Error(
                  `Server returned ${bytesDownloaded} bytes for a ${expectedBytes}-byte range`
                )
              )
              return
            }
            endBody()
          })
        })
        .catch(fail)
    }

    attempt(new URL(url), MAX_REDIRECTS)
  })
}

/** Fetches `start`..`end` into memory, following redirects, and reports which version served
 * it — used to compare a few bytes already on disk against what a server serves now. */
export function fetchRange(
  url: string,
  start: number,
  end: number,
  connection: StreamConnection,
  browser?: BrowserContext
): Promise<{ body: Buffer; version: FileVersion }> {
  return new Promise((resolve, reject) => {
    const attempt = (target: URL, redirectsLeft: number): void => {
      void connection
        .request(target, { ...requestHeaders(target, browser), Range: `bytes=${start}-${end}` })
        .then(({ req, res }) => {
          req.on('error', reject)
          const status = res.statusCode ?? 0
          if (status >= 300 && status < 400 && res.headers.location && redirectsLeft > 0) {
            res.resume()
            attempt(new URL(res.headers.location, target), redirectsLeft - 1)
            return
          }
          const served = parseContentRange(res.headers['content-range'])
          if (status !== 206 || served?.start !== start) {
            res.resume()
            reject(new Error(`Unexpected response to a sample request (status ${status})`))
            return
          }
          const chunks: Buffer[] = []
          res.setTimeout(STALL_TIMEOUT_MS, () => req.destroy(new Error('Sample request stalled')))
          res.on('data', (chunk: Buffer) => chunks.push(chunk))
          res.on('error', reject)
          res.on('end', () =>
            resolve({ body: Buffer.concat(chunks), version: versionOf(res, served) })
          )
        })
        .catch(reject)
    }
    attempt(new URL(url), MAX_REDIRECTS)
  })
}
