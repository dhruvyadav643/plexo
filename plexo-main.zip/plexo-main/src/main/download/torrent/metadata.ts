import { open } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import type WebTorrent from 'webtorrent'
import type { MagnetCheckStatus, ProbeResult } from '../../../shared/types'
import { testKnobs } from '../../testKnobs'
import { createClient } from './engine'
import { safeTorrentPaths } from './paths'

/** A .torrent file is metadata only; a link answering with more than this isn't one. */
const MAX_TORRENT_FILE_BYTES = 10 * 1024 * 1024
const TOO_LARGE = 'Plexo supports .torrent files up to 10 MB.'
const V2_ONLY = 'This torrent uses BitTorrent v2 only, which Plexo doesn’t support yet'
const NO_PEERS = 'No peers responded to this magnet link. Try again later or open a .torrent file.'
const NO_ONE_FOUND =
  'Couldn’t find anyone sharing this magnet link. A VPN or firewall may be blocking BitTorrent; ' +
  'otherwise try again later or open a .torrent file.'

/** The .torrent of each torrent probed lately, by info hash: what a download of it starts from,
 * so the window never has to hold or send it. */
const recent = new Map<string, Uint8Array>()
const RECENT_LIMIT = 8

export function probedTorrentFile(infoHash: string): Uint8Array | undefined {
  return recent.get(infoHash)
}

function remember(infoHash: string, torrentFile: Uint8Array): void {
  recent.delete(infoHash)
  recent.set(infoHash, torrentFile)
  if (recent.size > RECENT_LIMIT) recent.delete(recent.keys().next().value!)
}

/** What a .torrent holds, as a probe result — once its paths are known to be safe to write. */
export async function describeTorrent(torrentFile: Uint8Array, link: string): Promise<ProbeResult> {
  const { default: parseTorrent } = await import('parse-torrent')
  const parsed = await parseTorrent(torrentFile).catch((error: unknown) => {
    // parse-torrent's check for the v1 piece hashes, which a v2-only torrent doesn't have.
    if (error instanceof Error && error.message.endsWith('info.pieces')) throw new Error(V2_ONLY)
    throw new Error('This isn’t a torrent Plexo can read')
  })
  const files = safeTorrentPaths(parsed.files ?? [])
  remember(parsed.infoHash, torrentFile)
  return {
    kind: 'torrent',
    requestedUrl: link,
    finalUrl: link,
    supportsRanges: true,
    totalBytes: parsed.length ?? 0,
    suggestedFileName: parsed.name ?? parsed.infoHash,
    contentType: 'application/x-bittorrent',
    etag: null,
    lastModified: null,
    torrent: {
      infoHash: parsed.infoHash,
      pieceLength: parsed.pieceLength ?? 0,
      files,
      trackers: Array.isArray(parsed.announce) ? parsed.announce : [],
      isPrivate: Boolean(parsed.private)
    }
  }
}

/** A .torrent file on this computer. */
export async function readTorrentFile(path: string): Promise<Uint8Array> {
  const handle = await open(path, 'r')
  try {
    if ((await handle.stat()).size > MAX_TORRENT_FILE_BYTES) throw new Error(TOO_LARGE)
    return await handle.readFile()
  } finally {
    await handle.close()
  }
}

/** A .torrent file a link points at. `headers` are for `url`: on a redirect to another origin,
 * fetch drops their Cookie. */
export async function downloadTorrentFile(
  url: string,
  timeoutMs: number,
  headers: Record<string, string>
): Promise<Uint8Array> {
  const response = await fetch(url, {
    headers,
    signal: AbortSignal.timeout(timeoutMs)
  })
  if (!response.ok || !response.body) {
    throw new Error(`Server responded with status ${response.status}`)
  }
  const chunks: Uint8Array[] = []
  let total = 0
  for await (const chunk of response.body) {
    total += chunk.length
    if (total > MAX_TORRENT_FILE_BYTES) throw new Error(TOO_LARGE)
    chunks.push(chunk)
  }
  return Buffer.concat(chunks)
}

/** Fetches magnet links' metadata from their peers, over the default route: only a download's
 * own client pins peers to networks. Kept for the app's life, so its DHT stays warm. */
let probeClient: Promise<WebTorrent> | null = null
/** The magnet link being looked up. A newer one replaces it: the window only shows the latest. */
let current: { infoHash: string; metadata: Promise<Uint8Array>; cancel: () => void } | null = null

const statusListeners = new Set<(status: MagnetCheckStatus) => void>()

/** Hears how each magnet link's check is going, for the window to show while it waits. */
export function onMagnetCheckStatus(listener: (status: MagnetCheckStatus) => void): () => void {
  statusListeners.add(listener)
  return () => statusListeners.delete(listener)
}

function tellStatus(status: MagnetCheckStatus): void {
  for (const listener of statusListeners) listener(status)
}

/** A magnet link's .torrent, from whichever of its peers answers first. */
export async function fetchMagnetMetadata(magnet: string): Promise<Uint8Array> {
  const { default: parseTorrent } = await import('parse-torrent')
  const { infoHash, announce, peerAddresses, xs } = await parseTorrent(magnet).catch(() => {
    throw new Error('This magnet link isn’t valid')
  })
  // Only the DHT can help a link that names no tracker, no peer and no .torrent to fetch (xs).
  const dhtOnly = !announce?.length && !peerAddresses?.length && !xs?.length
  if (current?.infoHash === infoHash) return current.metadata
  current?.cancel()

  probeClient ??= createClient()
  const client = await probeClient
  const lookup = { infoHash } as NonNullable<typeof current>
  // Set first: a lookup that ends at once must still be able to clear itself.
  current = lookup
  lookup.metadata = new Promise<Uint8Array>((resolve, reject) => {
    // Deselected: only the metadata is wanted, none of the files.
    const torrent = client.add(magnet, { path: join(tmpdir(), 'plexo-magnet'), deselect: true })
    let done = false
    // Set while it keeps looking after a first search that found no one.
    let lookingLonger: { giveUp: NodeJS.Timeout; searchAgain: NodeJS.Timeout } | null = null
    let stopSearch = (): void => {}
    const stopLookingLonger = (): void => {
      if (!lookingLonger) return
      clearTimeout(lookingLonger.giveUp)
      clearTimeout(lookingLonger.searchAgain)
      lookingLonger = null
    }
    const finish = (error: Error | null, torrentFile?: Uint8Array): void => {
      if (done) return
      done = true
      clearTimeout(timer)
      stopLookingLonger()
      stopSearch()
      if (current === lookup) current = null
      torrent.destroy({ destroyStore: true })
      if (error) reject(error)
      else resolve(torrentFile!)
    }
    const timer = setTimeout(() => finish(new Error(NO_PEERS)), testKnobs.magnetTimeoutMs)

    // A link only the DHT can help: when its first search comes back empty, its next is 15
    // minutes off, so waiting out the timeout would only delay the same answer. It looks a little
    // longer instead: the first search after launch can miss peers while the DHT's table is still
    // filling, so it searches once more, and a peer that found this one through its announce can
    // still connect. Anyone turning up puts it back on the usual wait.
    let found = 0
    const foundSomeone = (): void => {
      found++
      if (!lookingLonger) return
      stopLookingLonger()
      tellStatus({ link: magnet, noPeersYet: false })
    }
    torrent.on('peer', foundSomeone)
    torrent.on('wire', foundSomeone)
    const firstSearchDone = (): void => {
      if (!dhtOnly || found > 0 || done) return
      const dht = client.dht
      // No DHT: nothing at all can find a peer for it.
      if (!dht) return finish(new Error(NO_ONE_FOUND))
      tellStatus({ link: magnet, noPeersYet: true })
      lookingLonger = {
        giveUp: setTimeout(() => finish(new Error(NO_ONE_FOUND)), testKnobs.magnetGraceMs),
        searchAgain: setTimeout(() => {
          stopSearch = dht.lookup(infoHash)
        }, testKnobs.magnetGraceMs / 3)
      }
    }
    if (client.dht) torrent.once('dhtAnnounce', firstSearchDone)
    else setImmediate(firstSearchDone)
    torrent.once('metadata', () => finish(null, torrent.torrentFile))
    torrent.once('error', (error: Error) => finish(error))
    lookup.cancel = () => finish(new Error('Replaced by a newer link'))
  })
  return lookup.metadata
}
