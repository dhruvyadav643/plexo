import type { ProbeResult, UsenetServer } from '@shared/types'
import { cn } from 'cn'
import {
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  FolderOpen,
  Globe,
  Lock,
  Pencil,
  X
} from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { useFormatSpeedLimit } from '../hooks/useFormatSpeed'
import { useFreeSpace } from '../hooks/useFreeSpace'
import { useNetworkUsage } from '../hooks/useNetworks'
import { useNetworkVisuals } from '../hooks/useNetworkVisuals'
import { useDownloadSchedule } from '../hooks/useDownloadSchedule'
import { useAppStore } from '../store/useAppStore'
import {
  acceptedLink,
  describeError,
  describeFileCount,
  fileExtensionBadge,
  formatBytes,
  toDisplayPath
} from '../utils/format'
import { Button } from './ui/button'
import { Dialog, DialogContent, DialogTitle } from './ui/dialog'
import { ToggleGroup, ToggleGroupItem } from './ui/toggle-group'
import { TorrentFileList } from './TorrentFiles'
import { UsenetServerDialog } from './UsenetServerDialog'
import { Tooltip, TooltipContent, TooltipTrigger } from './ui/tooltip'
import { NetworkEditPopover } from './NetworkEditPopover'

type ProbeState =
  | { status: 'idle' }
  /** `noPeersYet`: a magnet link whose first search found no one, still being looked for. */
  | { status: 'probing'; noPeersYet?: boolean }
  | { status: 'ready'; result: ProbeResult }
  | { status: 'error'; message: string }

const PROBE_DEBOUNCE_MS = 600

type StreamsChoice = 'auto' | number
/** Streams per network the user can pick instead of Auto. */
const STREAMS_CHOICES: StreamsChoice[] = ['auto', 4, 8, 16, 32]

const labelClass = 'w-16 shrink-0 text-[12.5px] text-[var(--text-secondary)]'

function NetworkListNotice({
  status,
  error,
  onScan
}: {
  status: 'idle' | 'loading' | 'ready' | 'error'
  error: string | null
  onScan: () => void
}): React.JSX.Element {
  if (status === 'idle' || status === 'loading') {
    return (
      <span className="font-mono text-[12px] text-muted-foreground">Looking for networks…</span>
    )
  }
  const detail = error ? describeError(error) : ''
  return (
    <span className="flex flex-wrap items-center gap-2 text-[12.5px] leading-snug text-[var(--text-secondary)]">
      {status === 'error'
        ? `Plexo couldn’t list this computer’s networks.${detail ? ` ${detail}` : ''}`
        : 'No networks connected. Join a Wi-Fi network, plug in Ethernet, or connect your phone using USB tethering.'}
      <Button type="button" variant="secondary" size="xs" onClick={onScan}>
        Scan again
      </Button>
    </span>
  )
}

/** New download: a link, then only what differs from one download to the next — its name (or a
 * torrent's files), where it goes, over which networks, and how many streams each runs. Everything set once for every
 * download lives in Speed & data limits and the networks menu. */
export function NewDownloadDialog(): React.JSX.Element {
  const open = useAppStore((store) => store.newDownloadOpen)
  const close = useAppStore((store) => store.closeNewDownload)
  const formKey = useAppStore((store) => store.formKey)

  return (
    <Dialog open={open} disablePointerDismissal onOpenChange={(next) => !next && close()}>
      <DialogContent
        showCloseButton={false}
        className="flex max-h-[calc(100%-2rem)] flex-col gap-0 p-0 sm:max-w-[560px]"
      >
        {/* Mounted only while open, and keyed by what it shows, so each opening and each
            download stacked in it starts fresh. */}
        {open && <NewDownloadForm key={formKey} onDone={close} />}
      </DialogContent>
    </Dialog>
  )
}

function NewDownloadForm({ onDone }: { onDone: () => void }): React.JSX.Element {
  const { schedule, window: scheduleWindow } = useDownloadSchedule()
  const scheduledWait = schedule?.enabled && !scheduleWindow.allowed
  const interfaces = useAppStore((store) => store.interfaces)
  const interfacesStatus = useAppStore((store) => store.interfacesStatus)
  const interfacesError = useAppStore((store) => store.interfacesError)
  const loadInterfaces = useAppStore((store) => store.loadInterfaces)
  const homeDir = useAppStore((store) => store.homeDir)
  const url = useAppStore((store) => store.draftUrl)
  const setUrl = useAppStore((store) => store.setDraftUrl)
  const links = useAppStore((store) => store.links)
  const shownId = useAppStore((store) => store.shownId)
  const showLink = useAppStore((store) => store.showLink)
  const finishLink = useAppStore((store) => store.finishLink)
  const dropLink = useAppStore((store) => store.dropLink)
  const shownLink = links.find((link) => link.id === shownId)
  const position = shownLink ? links.indexOf(shownLink) : -1
  const storeDestinationDir = useAppStore((store) => store.destinationDir)
  const defaultDestinationDir = useAppStore((store) => store.defaultDestinationDir)
  const [oneOffDestinationDir, setOneOffDestinationDir] = useState<string | null>(null)
  const destinationDir = oneOffDestinationDir ?? storeDestinationDir
  const full = useAppStore(
    (store) =>
      Object.values(store.downloads).filter((download) => download.status === 'downloading')
        .length >= store.downloadsAtOnce
  )
  const networkVisual = useNetworkVisuals()
  const networkPreferences = useAppStore((store) => store.networkPreferences)
  const setNetworkPreference = useAppStore((store) => store.setNetworkPreference)
  const usage = useNetworkUsage(true)
  const formatSpeedLimit = useFormatSpeedLimit()
  const linkInput = useRef<HTMLInputElement>(null)

  const [probe, setProbe] = useState<ProbeState>({ status: 'idle' })
  // Tracks deselections rather than selections, so a newly-detected interface starts selected.
  // Starts from the last download's pick: the networks it left out are saved as `off`.
  const [deselectedInterfaceIds, setDeselectedInterfaceIds] = useState<string[]>(() =>
    Object.entries(useAppStore.getState().networkPreferences)
      .filter(([, preference]) => preference.off)
      .map(([id]) => id)
  )
  const [starting, setStarting] = useState(false)
  const [startError, setStartError] = useState<string | null>(null)
  const [fileNameOverride, setFileNameOverride] = useState<string | null>(null)
  // A torrent's files left out, by index: every file is downloaded unless unticked.
  const [skippedFiles, setSkippedFiles] = useState<number[]>([])
  // For this download only: the next one starts on Auto again.
  const [streamsChoice, setStreamsChoice] = useState<StreamsChoice>('auto')
  // The news server, for an NZB: undefined until it has been asked for, null when there's none.
  const [server, setServer] = useState<UsenetServer | null | undefined>(undefined)
  const [serverOpen, setServerOpen] = useState(false)
  const freeSpace = useFreeSpace(destinationDir)

  // Opened with nothing in it: a link on the clipboard is most likely what it's for, as download
  // managers have long assumed. Anything else on the clipboard is left alone.
  useEffect(() => {
    if (useAppStore.getState().draftUrl) return
    void window.plexo
      .readClipboardText()
      .then((text) => {
        const link = acceptedLink(text)
        const { draftUrl, startedUrl } = useAppStore.getState()
        if (link && link !== startedUrl && !draftUrl) setUrl(link)
      })
      .catch(() => {})
  }, [setUrl])

  useEffect(() => {
    const trimmed = url.trim()
    if (!trimmed) {
      // Resetting derived probe state when its trigger (the URL) is cleared.
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setProbe({ status: 'idle' })
      setFileNameOverride(null)
      setSkippedFiles([])
      return
    }

    // Checking here would go without the browser's sign-in, and could spend a single-use link.
    const { links: stacked, shownId: shown } = useAppStore.getState()
    const given = stacked.find((link) => link.id === shown)
    if (given && given.url !== trimmed) dropLink(given.id, false)
    setFileNameOverride(null)
    setSkippedFiles([])
    if (given?.url === trimmed && given.probe) {
      setProbe({ status: 'ready', result: given.probe })
      return
    }

    // Set once the link changes, cleared included: a magnet can take a while to answer, and its
    // answer is no longer wanted then.
    let stale = false
    setProbe({ status: 'probing' })
    const stopListening = window.plexo.onMagnetCheckStatus((status) => {
      if (stale || status.link !== trimmed) return
      setProbe((now) =>
        now.status === 'probing' ? { status: 'probing', noPeersYet: status.noPeersYet } : now
      )
    })
    const timer = setTimeout(async () => {
      try {
        const result = await window.plexo.probeUrl(trimmed)
        if (stale) return
        setProbe({ status: 'ready', result })
      } catch (error) {
        if (stale) return
        setProbe({ status: 'error', message: describeError(error) })
      }
    }, PROBE_DEBOUNCE_MS)

    return () => {
      stale = true
      clearTimeout(timer)
      stopListening()
    }
  }, [url, dropLink])

  const ready = probe.status === 'ready' ? probe.result : null
  const torrent = ready?.kind === 'torrent' ? ready.torrent : null
  const nzb = ready?.kind === 'nzb' ? ready.nzb : null

  // Asked for once an NZB turns up: no other download needs it.
  const wantsServer = nzb !== null && server === undefined
  useEffect(() => {
    if (!wantsServer) return
    void window.plexo
      .usenetServer()
      .then(setServer)
      .catch(() => setServer(null))
  }, [wantsServer])
  const chosenFiles = torrent
    ? torrent.files.flatMap((_, index) => (skippedFiles.includes(index) ? [] : [index]))
    : []
  // What will be downloaded: a torrent's chosen files, or the whole file.
  const sizeToFetch = torrent
    ? chosenFiles.reduce((sum, index) => sum + torrent.files[index].length, 0)
    : (ready?.totalBytes ?? null)
  const availableFreeSpace = destinationDir ? freeSpace : null
  const hasInsufficientSpace =
    availableFreeSpace !== null &&
    sizeToFetch !== null &&
    sizeToFetch > 0 &&
    sizeToFetch > availableFreeSpace
  const multiChunkAllowed = ready !== null && ready.supportsRanges && ready.totalBytes !== null
  const isSingleStreamOnly = ready !== null && !multiChunkAllowed

  const detectedIds = interfaces.map((iface) => iface.id)
  // A network that has used up its data limit can't carry anything, so it can't be picked.
  const isReached = (id: string): boolean => {
    const dataLimit = networkPreferences[id]?.dataLimit
    return dataLimit !== undefined && (usage[id] ?? 0) >= dataLimit
  }
  const availableIds = detectedIds.filter((id) => !isReached(id))
  const pickedIds = availableIds.filter((id) => !deselectedInterfaceIds.includes(id))
  // The last pick may be all used up. Then nothing is picked, rather than what was left out: a
  // network left out is often left out on purpose (a phone's metered data), so it's chosen here
  // by hand, never stood in for the one that ran out.
  const selectedInterfaceIds = isSingleStreamOnly ? pickedIds.slice(0, 1) : pickedIds
  // The networks of the last pick that have used up their data, to say why nothing is picked.
  const usedUpPick =
    pickedIds.length === 0 && availableIds.length > 0
      ? interfaces.filter(
          (iface) => isReached(iface.id) && !deselectedInterfaceIds.includes(iface.id)
        )
      : []

  const canStart =
    probe.status === 'ready' &&
    (!torrent || chosenFiles.length > 0) &&
    (!nzb || !!server) &&
    selectedInterfaceIds.length > 0 &&
    Boolean(destinationDir) &&
    !hasInsufficientSpace &&
    !starting
  const startLabel = starting
    ? 'Starting'
    : probe.status === 'probing'
      ? 'Checking'
      : scheduledWait
        ? 'Add to scheduled queue'
        : full
          ? 'Add to queue'
          : 'Download'

  // Two networks on one subnet: the OS sends both down one route, so there's nothing to combine.
  let subnetConflict: { subnet: string; names: string[] } | null = null
  if (selectedInterfaceIds.length > 1) {
    const subnets = new Map<string, string[]>()
    for (const id of selectedInterfaceIds) {
      const iface = interfaces.find((i) => i.id === id)
      const subnet = iface?.addresses.find((address) => address.family === 4)?.subnet
      if (subnet && iface) {
        const names = subnets.get(subnet) ?? []
        names.push(networkVisual(iface.id, iface.kind, iface.displayName).name)
        subnets.set(subnet, names)
      }
    }
    for (const [subnet, names] of subnets.entries()) {
      if (names.length > 1) {
        subnetConflict = { subnet, names }
        break
      }
    }
  }

  const handleToggleInterface = (id: string): void => {
    if (isReached(id)) return
    if (isSingleStreamOnly) {
      // Single-stream mode can only download through 1 interface at a time
      setDeselectedInterfaceIds(detectedIds.filter((otherId) => otherId !== id))
      return
    }
    setDeselectedInterfaceIds((prev) => {
      if (prev.includes(id)) return prev.filter((entry) => entry !== id)
      // Keep at least 1 interface selected
      const remaining = availableIds.filter((other) => !prev.includes(other) && other !== id)
      return remaining.length === 0 ? prev : [...prev, id]
    })
  }

  const handleBrowse = async (): Promise<void> => {
    const chosen = await window.plexo.chooseDestinationFolder(destinationDir)
    if (chosen) {
      if (defaultDestinationDir) {
        setOneOffDestinationDir(chosen)
      } else {
        useAppStore.getState().setDestinationDir(chosen)
      }
    }
  }

  // A .torrent or .nzb file goes in the link field as its path; the probe reads it from there.
  const handleOpenFile = async (): Promise<void> => {
    const path = await window.plexo.chooseDownloadFile()
    if (path) setUrl(path)
  }

  const handleResume = async (): Promise<void> => {
    const link = shownLink
    const resumes = link?.resumes
    if (!link || !resumes) return
    setStarting(true)
    setStartError(null)
    try {
      await window.plexo.resumeFromLink(link.id, resumes.id)
      useAppStore.setState({ view: { name: 'download', id: resumes.id } })
      finishLink(link.id, true)
    } catch (error) {
      setStartError(describeError(error))
      setStarting(false)
    }
  }

  const handleStart = async (): Promise<void> => {
    if (probe.status !== 'ready' || !canStart) return
    // Captured now: links can arrive and change what's shown while this starts.
    const linkId = shownLink?.id
    const form = useAppStore.getState().formKey
    setStarting(true)
    setStartError(null)
    try {
      const common = {
        url: probe.result.finalUrl,
        destinationDir,
        suggestedFileName: fileNameOverride?.trim() || probe.result.suggestedFileName,
        totalBytes: probe.result.totalBytes ?? 0,
        supportsRanges: multiChunkAllowed,
        interfaceIds: selectedInterfaceIds,
        etag: probe.result.etag,
        lastModified: probe.result.lastModified
      }
      const id = await window.plexo.startDownload(
        probe.result.kind === 'torrent'
          ? {
              ...common,
              kind: 'torrent',
              infoHash: probe.result.torrent.infoHash,
              selectedFiles: skippedFiles.length > 0 ? chosenFiles : undefined
            }
          : probe.result.kind === 'nzb'
            ? { ...common, kind: 'nzb', nzbHash: probe.result.nzb.hash }
            : {
                ...common,
                kind: 'http',
                requestedUrl: probe.result.requestedUrl,
                streamsPerNetwork: streamsChoice === 'auto' ? undefined : streamsChoice
              },
        linkId
      )
      // Remembered for the next download, like the folder. Not a single-stream pick: that's one
      // network because the file allows no more, not because the others were unwanted.
      if (!isSingleStreamOnly) {
        for (const id of availableIds) {
          const off = !selectedInterfaceIds.includes(id)
          if (off !== Boolean(networkPreferences[id]?.off)) {
            setNetworkPreference(id, { off: off || undefined })
          }
        }
      }
      // Started: the link is spent, so the next download starts from an empty one. Its own
      // screen opens, unless it was only added to the queue.
      useAppStore.setState({
        startedUrl: url.trim(),
        ...(full || scheduledWait ? {} : { view: { name: 'download', id } as const })
      })
      if (linkId) {
        finishLink(linkId, true)
      } else if (useAppStore.getState().formKey === form) {
        // Only while this form is still the one shown: closing would dismiss a link that arrived.
        useAppStore.setState({ draftUrl: '' })
        onDone()
      }
    } catch (error) {
      setStartError(describeError(error))
      setStarting(false)
    }
  }

  const fileName = ready ? (fileNameOverride ?? ready.suggestedFileName) : ''

  return (
    <form
      className="flex min-h-0 flex-col"
      onSubmit={(event) => {
        event.preventDefault()
        void handleStart()
      }}
    >
      <div className="flex items-center gap-2 border-b-[0.5px] border-border py-3 pr-3 pl-5">
        <DialogTitle className="flex-1 py-1 text-[16px] font-semibold">New download</DialogTitle>
        {shownLink && links.length > 1 && (
          <div className="flex items-center gap-1">
            <Button
              type="button"
              variant="ghost"
              size="icon-sm"
              aria-label="Previous download"
              disabled={position === 0}
              onClick={() => showLink(links[position - 1].id)}
            >
              <ChevronLeft />
            </Button>
            <span className="min-w-12 text-center font-mono text-[11.5px] text-muted-foreground tabular-nums">
              {position + 1} of {links.length}
            </span>
            <Button
              type="button"
              variant="ghost"
              size="icon-sm"
              aria-label="Next download"
              disabled={position === links.length - 1}
              onClick={() => showLink(links[position + 1].id)}
            >
              <ChevronRight />
            </Button>
          </div>
        )}
      </div>

      <div className="flex min-h-0 flex-col gap-3.5 overflow-y-auto px-5 py-4">
        <div className="flex items-center gap-2">
          <div
            className={cn(
              'flex h-9 min-w-0 flex-1 items-center gap-2 rounded-[9px] border bg-[var(--input-bg)] px-3',
              probe.status === 'error' ? 'border-destructive' : 'border-input'
            )}
          >
            <input
              ref={linkInput}
              autoFocus
              type="text"
              value={url}
              onChange={(event) => setUrl(event.target.value)}
              placeholder="Paste a link: https:// or magnet:"
              spellCheck={false}
              aria-label="Link"
              className="min-w-0 flex-1 border-none bg-transparent font-mono text-[13px] text-foreground outline-none"
            />
            {url && (
              <Tooltip>
                <TooltipTrigger
                  render={
                    <button
                      type="button"
                      onClick={() => {
                        setUrl('')
                        linkInput.current?.focus()
                      }}
                      aria-label="Clear link"
                      className="flex size-5 shrink-0 cursor-default items-center justify-center rounded-full text-muted-foreground hover:bg-secondary hover:text-foreground"
                    >
                      <X aria-hidden className="size-3.5" />
                    </button>
                  }
                />
                <TooltipContent>Clear link</TooltipContent>
              </Tooltip>
            )}
          </div>
          <Tooltip>
            <TooltipTrigger
              render={
                <Button type="button" variant="secondary" onClick={handleOpenFile} className="h-9">
                  <FolderOpen data-icon="inline-start" />
                  Open file
                </Button>
              }
            />
            <TooltipContent>Open a .torrent or .nzb file</TooltipContent>
          </Tooltip>
        </div>

        {shownLink?.from && (
          <div className="flex h-6 items-center gap-1.5 self-start rounded-full border-[0.5px] border-[var(--color-wifi-border)] bg-[var(--color-wifi-bg)] px-2.5 text-[12px] font-medium text-[var(--color-wifi-text)]">
            {shownLink.signedInTo ? (
              <Lock aria-hidden className="size-3" />
            ) : (
              <Globe aria-hidden className="size-3" />
            )}
            {[
              `From ${shownLink.from}`,
              shownLink.signedInTo && `with your ${shownLink.signedInTo} sign-in`
            ]
              .filter(Boolean)
              .join(' · ')}
          </div>
        )}

        {shownLink?.resumes && (
          <div className="flex items-center gap-3 rounded-lg border-[0.5px] border-border bg-card px-3 py-2 text-[12.5px]">
            <span className="min-w-0 flex-1">
              Same file as <span className="font-medium">{shownLink.resumes.fileName}</span>, which
              failed. Resume that instead?
            </span>
            <Button
              type="button"
              variant="secondary"
              size="sm"
              disabled={starting}
              onClick={() => void handleResume()}
            >
              Resume it
            </Button>
          </div>
        )}

        {probe.status === 'probing' && (
          <div className="font-mono text-[11.5px] text-muted-foreground">
            {probe.noPeersYet ? 'No peers found yet, still looking…' : 'Checking the link…'}
          </div>
        )}
        {probe.status === 'error' && (
          <div className="flex items-center gap-2 text-[12.5px] text-[var(--color-danger)]">
            <AlertTriangle className="size-4 shrink-0" />
            {probe.message}
          </div>
        )}

        {ready && (
          <div className="flex items-center gap-3">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-lg border-[0.5px] border-border bg-card font-mono text-[10px] font-semibold text-muted-foreground">
              {(torrent && torrent.files.length > 1) || nzb ? 'DIR' : fileExtensionBadge(fileName)}
            </div>
            <div className="flex min-w-0 flex-1 flex-col gap-1">
              {torrent ? (
                <div className="truncate text-[14px] font-medium">{ready.suggestedFileName}</div>
              ) : (
                <input
                  type="text"
                  value={fileName}
                  onChange={(event) => setFileNameOverride(event.target.value)}
                  aria-label="File name"
                  spellCheck={false}
                  className="min-w-0 rounded-md border border-transparent bg-transparent px-1 -ml-1 text-[14px] font-medium outline-none hover:border-input focus:border-input"
                />
              )}
              <div className="font-mono text-[11.5px] text-muted-foreground">
                {[
                  torrent && describeFileCount(chosenFiles.length, torrent.files.length),
                  nzb && describeFileCount(nzb.files.length, nzb.files.length),
                  sizeToFetch !== null ? formatBytes(sizeToFetch) : 'size unknown',
                  nzb && 'from Usenet',
                  !torrent &&
                    !nzb &&
                    (isSingleStreamOnly
                      ? ready.supportsRanges
                        ? 'Uses one connection. The file size is unknown.'
                        : 'Uses one connection. This server doesn’t support parallel downloads.'
                      : 'resumable')
                ]
                  .filter(Boolean)
                  .join(' · ')}
              </div>
            </div>
          </div>
        )}

        {torrent && (
          <TorrentFileList
            files={torrent.files}
            skipped={skippedFiles}
            onChange={setSkippedFiles}
          />
        )}

        {nzb && server !== undefined && (
          <div className="flex items-center gap-3">
            <div className={labelClass}>Server</div>
            {server ? (
              <div className="min-w-0 flex-1 truncate font-mono text-[12.5px]">
                {server.host}
                <span className="text-muted-foreground">
                  {' '}
                  · {server.connections} {server.connections === 1 ? 'connection' : 'connections'}
                </span>
              </div>
            ) : (
              <div className="flex min-w-0 flex-1 items-center gap-2 text-[12.5px] text-[var(--color-usb-text)]">
                <AlertTriangle aria-hidden className="size-3.5 shrink-0" />
                Set up your news server to download this NZB.
              </div>
            )}
            <Button type="button" variant="secondary" size="sm" onClick={() => setServerOpen(true)}>
              {server ? 'Change' : 'Set up'}
            </Button>
          </div>
        )}

        <div className="flex items-center gap-3">
          <div className={labelClass}>Save to</div>
          <div className="flex min-w-0 flex-1 items-baseline gap-2 truncate font-mono text-[12.5px]">
            <span className="truncate">{toDisplayPath(destinationDir, homeDir)}</span>
            {availableFreeSpace !== null && (
              <span
                className={cn(
                  'shrink-0 text-[11.5px] tabular-nums',
                  hasInsufficientSpace
                    ? 'font-medium text-[var(--color-danger)]'
                    : 'text-muted-foreground'
                )}
              >
                ({formatBytes(availableFreeSpace)} free)
              </span>
            )}
          </div>
          <Button type="button" variant="secondary" size="sm" onClick={handleBrowse}>
            Change
          </Button>
        </div>

        <div className="flex items-start gap-3">
          <div className={cn(labelClass, 'pt-1.5')} id="new-download-networks">
            Networks
          </div>
          <div
            role="group"
            aria-labelledby="new-download-networks"
            className="flex min-w-0 flex-1 flex-wrap gap-1.5"
          >
            {interfaces.length === 0 && (
              <NetworkListNotice
                status={interfacesStatus}
                error={interfacesError}
                onScan={() => void loadInterfaces()}
              />
            )}
            {interfaces.map((iface) => {
              const visual = networkVisual(iface.id, iface.kind, iface.displayName)
              const selected = selectedInterfaceIds.includes(iface.id)
              const reached = isReached(iface.id)
              const preference = networkPreferences[iface.id]
              const speedLimit = preference?.speedLimit
              const proxy = preference?.proxy
              const isProxyActive = Boolean(proxy?.enabled && proxy.host)
              // What's worth knowing before it's picked: it can't be, or it's capped.
              const note = reached
                ? 'Data limit reached'
                : speedLimit !== undefined
                  ? `Limited to ${formatSpeedLimit(speedLimit)}`
                  : null

              const toggleButton = (
                <button
                  type="button"
                  aria-pressed={selected}
                  // Not `disabled`: a disabled button never gets the hover that says why.
                  aria-disabled={reached || undefined}
                  onClick={() => handleToggleInterface(iface.id)}
                  className={cn(
                    'flex items-center gap-1.5 focus-visible:outline-none cursor-pointer select-none py-1',
                    reached && 'cursor-not-allowed line-through'
                  )}
                >
                  <span
                    className="size-2 rounded-full shrink-0"
                    style={{ background: visual.solid }}
                  />
                  <span className="truncate">{visual.name}</span>
                </button>
              )

              return (
                <div
                  key={iface.id}
                  className={cn(
                    'group/chip inline-flex h-7 items-center rounded-full border text-[12.5px] transition-colors pl-2.5 pr-1 gap-1',
                    selected
                      ? 'border-transparent'
                      : 'border-border text-[var(--text-secondary)] opacity-70',
                    reached && 'opacity-50'
                  )}
                  style={
                    selected ? { background: visual.bg, borderColor: visual.border } : undefined
                  }
                >
                  {note === null ? (
                    toggleButton
                  ) : (
                    <Tooltip>
                      <TooltipTrigger render={toggleButton} />
                      <TooltipContent>{note}</TooltipContent>
                    </Tooltip>
                  )}

                  <NetworkEditPopover
                    interfaceId={iface.id}
                    interfaceKind={iface.kind}
                    osName={iface.displayName}
                    defaultFocusProxy={true}
                    trigger={
                      <Button
                        type="button"
                        variant="ghost"
                        size="xs"
                        aria-label={
                          isProxyActive
                            ? `Configure proxy (${proxy!.type.toUpperCase()}) or edit ${visual.name}`
                            : `Configure proxy or edit ${visual.name}`
                        }
                        className={cn(
                          'h-5 px-1.5 rounded-full text-muted-foreground hover:text-foreground shrink-0 gap-1 flex items-center font-mono text-[9px] uppercase tracking-[0.04em]',
                          isProxyActive
                            ? 'font-semibold text-foreground bg-foreground/10 hover:bg-foreground/15'
                            : 'hover:bg-foreground/10'
                        )}
                      >
                        {isProxyActive ? (
                          <>
                            <span>PROXY · {proxy!.type}</span>
                            <Pencil className="size-2.5 opacity-70" />
                          </>
                        ) : (
                          <>
                            <Pencil className="size-2.5 opacity-70" />
                            <span className="capitalize font-sans text-[10.5px]">Proxy</span>
                          </>
                        )}
                      </Button>
                    }
                    tooltip={
                      isProxyActive
                        ? `Proxy active (${proxy!.type.toUpperCase()} · ${proxy!.host}:${proxy!.port}) — click to configure`
                        : `Configure proxy or edit ${visual.name}`
                    }
                  />
                </div>
              )
            })}
          </div>
        </div>

        {/* A torrent's speed comes from its peers, an NZB's connections are the server's, and an
            unsplittable file has one stream. */}
        {ready && !torrent && !nzb && !isSingleStreamOnly && (
          <div className="flex items-center gap-3">
            <div className={labelClass} id="new-download-streams">
              Streams
            </div>
            <ToggleGroup
              value={[String(streamsChoice)]}
              onValueChange={(values) => {
                if (values.length === 0) return
                setStreamsChoice(values[0] === 'auto' ? 'auto' : Number(values[0]))
              }}
              aria-labelledby="new-download-streams"
              variant="pill"
              size="xs"
              spacing={1}
            >
              {STREAMS_CHOICES.map((choice) => (
                // h-6/min-w-6: WCAG 2.5.8's 24px floor — the xs toggle size is 20px.
                <ToggleGroupItem key={choice} value={String(choice)} className="h-6 min-w-6 px-2">
                  {choice === 'auto' ? 'Auto' : choice}
                </ToggleGroupItem>
              ))}
            </ToggleGroup>
            <div className="font-mono text-[11px] text-muted-foreground">per network</div>
          </div>
        )}

        {subnetConflict && (
          <div className="flex items-start gap-2 text-[12px] leading-snug text-[var(--color-usb-text)]">
            <AlertTriangle className="mt-0.5 size-3.5 shrink-0" />
            {subnetConflict.names.join(' and ')} share a subnet ({subnetConflict.subnet}), so the
            computer sends both down one route and they can’t be combined.
          </div>
        )}
        {hasInsufficientSpace && (
          <div
            role="alert"
            className="flex items-start gap-2 text-[12px] leading-snug text-[var(--color-danger)]"
          >
            <AlertTriangle className="mt-0.5 size-3.5 shrink-0" />
            <span>
              Not enough disk space: this download needs {formatBytes(sizeToFetch)}, but only{' '}
              {formatBytes(availableFreeSpace)} is free on this drive.
            </span>
          </div>
        )}
        {usedUpPick.length > 0 && (
          <div className="flex items-start gap-2 text-[12px] leading-snug text-[var(--color-usb-text)]">
            <AlertTriangle className="mt-0.5 size-3.5 shrink-0" />
            {usedUpPick
              .map((iface) => networkVisual(iface.id, iface.kind, iface.displayName).name)
              .join(' and ')}{' '}
            {usedUpPick.length === 1 ? 'has' : 'have'} reached{' '}
            {usedUpPick.length === 1 ? 'its' : 'their'} data limit. Choose another network for this
            download.
          </div>
        )}
        {interfaces.length > 0 && availableIds.length === 0 && (
          <div className="flex items-start gap-2 text-[12px] leading-snug text-[var(--color-usb-text)]">
            <AlertTriangle className="mt-0.5 size-3.5 shrink-0" />
            Every network has reached its data limit. Raise one in Speed &amp; data limits.
          </div>
        )}
        {isSingleStreamOnly && selectedInterfaceIds.length === 1 && interfaces.length > 1 && (
          <div className="text-[12px] text-muted-foreground">
            This download uses one connection on one network.
          </div>
        )}
      </div>

      <div className="flex items-center gap-2 border-t-[0.5px] border-border px-4 py-2">
        {startError ? (
          <div className="min-w-0 flex-1 truncate text-[12.5px] text-[var(--color-danger)]">
            {startError}
          </div>
        ) : (
          <div className="flex-1" />
        )}
        <Button type="button" variant="secondary" onClick={onDone}>
          Cancel
        </Button>
        <Button type="submit" disabled={!canStart}>
          {startLabel}
        </Button>
      </div>
      {/* Its form keeps its submit to itself: a portal's events still bubble up the React tree. */}
      <UsenetServerDialog
        open={serverOpen}
        server={server ?? null}
        onOpenChange={setServerOpen}
        onSaved={setServer}
      />
    </form>
  )
}
