import { SPEED_HISTORY_SECONDS, type DownloadState } from '@shared/types'
import { AlertTriangle, Folder } from 'lucide-react'
import { memo, useEffect, useState } from 'react'
import { BlockGrid } from '../components/BlockGrid'
import { ColorBadge } from '../components/ColorBadge'
import { CombineDiagram } from '../components/CombineDiagram'
import { CyclableChip } from '../components/CyclableChip'
import { HeroBand } from '../components/HeroBand'
import { NetworkRow } from '../components/NetworkRow'
import { DetailHeader } from '../components/DetailHeader'
import { ThroughputChart } from '../components/ThroughputChart'
import { TorrentFiles } from '../components/TorrentFiles'
import { TorrentBadge } from '../components/TorrentBadge'
import { TruncatedText } from '../components/TruncatedText'
import { UsenetBadge } from '../components/UsenetBadge'
import { UsenetServerButton } from '../components/UsenetServerDialog'
import { Button } from '../components/ui/button'
import { Tooltip, TooltipContent, TooltipTrigger } from '../components/ui/tooltip'
import { useNetworkVisuals } from '../hooks/useNetworkVisuals'
import { useCombineFlow, type ShownFlowChange } from '../hooks/useCombineFlow'
import { flowStep } from '../utils/combineFlow'
import type { NetworkVisual } from '../theme'
import { useDownloadSchedule } from '../hooks/useDownloadSchedule'
import { useAppStore } from '../store/useAppStore'
import { useDownloadActions } from '../components/downloadActionsContext'
import { KIND_PALETTE, NETWORK_ROW_GRID_COLUMNS } from '../theme'
import {
  describeError,
  describeFileCount,
  dirnameOf,
  fileExtensionBadge,
  formatBytes,
  formatEta,
  formatPercent,
  groupByNetwork,
  isFolder,
  networkActive,
  networksInPlay,
  toDisplayPath,
  wantedBytes
} from '../utils/format'
import { useFormatSpeed, useFormatSpeedLimit } from '../hooks/useFormatSpeed'

/** Inline "·" separator between adjacent stats. `shrink` pins it at its natural width inside a
 * flex row that might otherwise squeeze it (footer rows), matching each call site's prior style. */
function Dot(): React.JSX.Element {
  return <span className="opacity-35">·</span>
}

function InlineStat({ label, value }: { label: string; value: string }): React.JSX.Element {
  return (
    <span>
      {label} <span className="font-semibold text-foreground">{value}</span>
    </span>
  )
}

/** The hero band's headline figure: a tracked-out label over one big tabular number and its unit. */
function BigStat({
  label,
  value,
  unit,
  valueClass,
  note,
  aside
}: {
  label: string
  value: string | number
  unit?: string
  valueClass: string
  /** Beside the label, e.g. a warning about what holds the value down. */
  note?: React.ReactNode
  /** After the value and its unit, e.g. how much a network that just joined added to it. */
  aside?: React.ReactNode
}): React.JSX.Element {
  return (
    <>
      <div className="flex items-center gap-1.5 font-mono text-[10px] leading-none font-medium tracking-[0.2em] text-muted-foreground">
        {label}
        {note}
      </div>
      <div className="flex items-baseline gap-[7px]">
        <div
          className={`font-mono text-[38px] leading-[0.88] font-semibold tracking-[-0.03em] tabular-nums ${valueClass}`}
        >
          {value}
        </div>
        {unit && (
          <div className="font-mono text-[12px] leading-none font-medium text-muted-foreground">
            {unit}
          </div>
        )}
        {aside}
      </div>
    </>
  )
}

/** "+12 MB/s" beside the total speed for a moment after a network joins the download, or
 * "−8 MB/s" after one drops out: the moment the total changed, and why. Always rendered, so it
 * is a live region a screen reader is already watching when the text arrives; its text comes
 * and goes with useCombineFlow, and only its arrival is animated (see plexo-rise-in). */
function SpeedChange({
  change,
  visual,
  formatSpeed
}: {
  change: ShownFlowChange | null
  visual: NetworkVisual | undefined
  formatSpeed: (bytesPerSec: number) => string
}): React.JSX.Element {
  const joined = change?.change === 'joined'
  return (
    <span role="status" className="self-baseline">
      {change && visual && (
        <span
          key={change.key}
          data-testid="speed-change"
          className="inline-block font-mono text-[11px] leading-none font-semibold whitespace-nowrap tabular-nums"
          style={{
            color: joined ? visual.solid : 'var(--text-tertiary)',
            animation: 'plexo-rise-in 240ms cubic-bezier(0.16, 1, 0.3, 1) both'
          }}
        >
          <span className="sr-only">{`${visual.name} ${joined ? 'joined' : 'dropped out'}: `}</span>
          {`${joined ? '+' : '−'}${formatSpeed(change.bytesPerSec)}`}
        </span>
      )}
    </span>
  )
}

/** An NZB download's files, once its articles are in (see NzbPostProcess). */
const STAGE_LABELS = {
  verifying: 'Verifying with par2…',
  repairing: 'Repairing with par2…',
  unpacking: 'Unpacking…'
} as const

/** What the download is waiting on, when no network is carrying it. */
function waitingFor(download: DownloadState): string | null {
  if (download.status !== 'downloading') return null
  const enabled = download.networks.filter((network) => network.enabled)
  if (enabled.some((network) => network.status === 'on')) return null
  if (enabled.some((network) => network.status === 'unreachable')) {
    return download.kind === 'torrent'
      ? 'Can’t reach peers. Retrying…'
      : download.kind === 'nzb'
        ? 'Can’t reach the news server. Retrying…'
        : 'Can’t reach the server. Retrying…'
  }
  return enabled.length > 0 && enabled.every((network) => network.status === 'limit')
    ? 'Every network in use has reached its data limit. Raise one in Speed & data limits.'
    : 'Waiting for a network. Reconnect one or switch one on.'
}

// Memoized: its grid and tables are the heaviest thing on screen, so nothing but its own
// download's update (which brings a new object) should re-render it.
export const DownloadingScreen = memo(function DownloadingScreen({
  download
}: {
  download: DownloadState
}): React.JSX.Element {
  const formatSpeed = useFormatSpeed()
  const formatSpeedLimit = useFormatSpeedLimit()
  const homeDir = useAppStore((store) => store.homeDir)
  const speedLimit = useAppStore((store) => store.speedLimit)
  const slowMode = useAppStore((store) => store.slowMode)
  const slowModeSpeed = useAppStore((store) => store.slowModeSpeed)
  const speedHistory = download.speedHistory ?? {}
  const peakSpeedBytesPerSec = download.peakSpeedBytesPerSec
  const networkVisual = useNetworkVisuals()
  const { window: scheduleWindow, message: scheduleMessage } = useDownloadSchedule()
  const { perform } = useDownloadActions()
  const isQueued = download.status === 'queued'
  // Waiting in the queue looks like a pause: nothing moves.
  const isPaused = download.status === 'paused' || isQueued
  const isTorrent = download.kind === 'torrent'
  const percent = formatPercent(download.bytesDownloaded, wantedBytes(download))
  const knownSize = download.totalBytes > 0
  const missingArticles =
    download.kind === 'nzb' ? download.nzbFiles.reduce((sum, file) => sum + file.missing, 0) : 0
  const [now, setNow] = useState(() => Date.now())

  useEffect(() => {
    if (isPaused) return
    const interval = setInterval(() => setNow(Date.now()), 1000)
    return () => clearInterval(interval)
  }, [isPaused])

  const [filesOpen, setFilesOpen] = useState(false)
  useEffect(() => {
    if (isPaused) {
      const label = isQueued ? 'Queued' : 'Paused'
      document.title = knownSize ? `Plexo — ${label} (${percent}%)` : `Plexo — ${label}`
    } else {
      document.title = knownSize ? `Plexo — ${percent}%` : 'Plexo — downloading'
    }
    return () => {
      document.title = 'Plexo'
    }
  }, [percent, knownSize, isPaused, isQueued])

  const totalPausedMs =
    (download.totalPausedMs || 0) +
    (isPaused && download.pausedAt ? Math.max(0, now - download.pausedAt) : 0)
  const elapsedSeconds = Math.max(0, (now - download.startedAt - totalPausedMs) / 1000)

  const effectiveSpeed = isPaused ? 0 : download.speedBytesPerSec
  const [speedValue, speedUnit] = formatSpeed(effectiveSpeed).split(' ')
  // The cap over every download, beside the speed it holds down — slow mode named, so a low
  // number explains itself.
  const speedCap = slowMode
    ? ` · SLOW MODE ${formatSpeedLimit(slowModeSpeed)}`
    : speedLimit !== undefined
      ? ` · LIMIT ${formatSpeedLimit(speedLimit)}`
      : ''
  // Every network is a row, for switching it on or off; the charts draw only those in play.
  const rows = groupByNetwork(download)
  const rowVisuals = rows.map((row) => networkVisual(row.id, row.kind, row.label))
  const groups = networksInPlay(rows)
  const visuals = groups.map((group) => networkVisual(group.id, group.kind, group.label))
  const totalDownloadedByNetworks = rows.reduce((sum, row) => sum + row.bytesDownloaded, 0)
  const [chipModeIndex, setChipModeIndex] = useState(0)
  const waiting = waitingFor(download)
  // Each network's path in the diagram is drawn by its share of the total right now, and the
  // moment one joins or drops out is marked (see useCombineFlow). Its steps lag the speeds by an
  // update at most; until it has one, a network's step comes straight from its share.
  const flow = useCombineFlow(download.id)
  const groupsSpeed = groups.reduce((sum, group) => sum + group.speedBytesPerSec, 0)
  const changedVisual = flow.change
    ? visuals[groups.findIndex((group) => group.id === flow.change?.networkId)]
    : undefined

  const totalRetries = rows.reduce((sum, row) => sum + row.retries, 0)
  const remainingBytes = knownSize
    ? Math.max(0, wantedBytes(download) - download.bytesDownloaded)
    : 0

  const avgSpeedBytesPerSec = elapsedSeconds > 0 ? download.bytesDownloaded / elapsedSeconds : 0

  // "N× WIFI ALONE": the combined download measured against one network on its own, by whichever
  // metric is live — current speed while bytes are moving, total downloaded otherwise. A network
  // that carried the download barely faster than it would alone (< 1.05×) makes no point worth a
  // chip. Cycling order is fastest network (smallest multiple) first, as it was.
  const bySpeed = download.speedBytesPerSec > 0
  const totalMetric = bySpeed ? download.speedBytesPerSec : download.bytesDownloaded
  const chipOptions =
    groups.length > 1 && !isPaused && totalMetric > 0
      ? groups
          .map((group, index) => ({
            ratio: totalMetric / (bySpeed ? group.speedBytesPerSec : group.bytesDownloaded),
            visual: visuals[index]
          }))
          .filter(({ ratio }) => Number.isFinite(ratio) && ratio >= 1.05)
          .sort((a, b) => a.ratio - b.ratio)
          .map(({ ratio, visual }) => ({
            visual,
            label: `${ratio.toFixed(1)}× ${visual.name.toUpperCase()} ALONE`,
            tooltip: bySpeed
              ? `Total speed is ${ratio.toFixed(1)}× faster than ${visual.name} alone`
              : `Total downloaded is ${ratio.toFixed(1)}× compared to ${visual.name} alone`
          }))
      : []

  const activeChipOption =
    chipOptions.length > 0 ? chipOptions[chipModeIndex % chipOptions.length] : null

  const statusBadge = isPaused
    ? { label: isQueued ? 'QUEUED' : 'PAUSED', palette: KIND_PALETTE.usb }
    : null

  const throughputStatusLabel = isPaused ? null : `LAST ${SPEED_HISTORY_SECONDS}S`

  return (
    <div className="flex h-full flex-col bg-background">
      <DetailHeader download={download} />
      {isQueued && !scheduleWindow.allowed && (
        <div className="border-b-[0.5px] border-border px-5 py-3 text-[12.5px] text-muted-foreground">
          {scheduleMessage}
        </div>
      )}
      {/* Hero band — always visible under the header */}
      <HeroBand>
        {/* At their designed size: a wider window opens a gap between the speed and the chart
            (ml-auto) rather than stretching the merge into rails or the chart into a ribbon. */}
        <div className="flex items-center gap-[14px]">
          <CombineDiagram
            networks={groups.map((group, index) => {
              const active = networkActive(group)
              const share = !isPaused && groupsSpeed > 0 ? group.speedBytesPerSec / groupsSpeed : 0
              return {
                id: group.id,
                solid: visuals[index].solid,
                label: visuals[index].name,
                speedBytesPerSec: isPaused ? 0 : group.speedBytesPerSec,
                active,
                share,
                step: flow.steps[group.id] ?? flowStep(share, active)
              }
            })}
            paused={isPaused}
            change={flow.change}
          />

          <div className="flex min-w-[130px] shrink-0 flex-col gap-[7px]">
            <>
              <BigStat
                label={`TOTAL SPEED${speedCap}`}
                value={isPaused ? '—' : speedValue}
                unit={isPaused ? undefined : speedUnit}
                valueClass={isPaused ? 'text-muted-foreground' : 'text-foreground'}
                aside={
                  <SpeedChange
                    change={isPaused ? null : flow.change}
                    visual={changedVisual}
                    formatSpeed={formatSpeed}
                  />
                }
                note={
                  !isPaused &&
                  download.kind === 'http' &&
                  download.diskLimited && (
                    <Tooltip>
                      <TooltipTrigger
                        render={
                          <span
                            role="img"
                            aria-label="Slow drive"
                            className="inline-flex text-[var(--swatch-amber)]"
                          >
                            <AlertTriangle aria-hidden className="size-3" />
                          </span>
                        }
                      />
                      <TooltipContent>
                        Your drive can’t save any faster, so this download is going slower.
                      </TooltipContent>
                    </Tooltip>
                  )
                }
              />
              <div className="flex items-center gap-2 font-mono text-[10px] leading-none font-medium tabular-nums text-muted-foreground">
                <InlineStat label="AVG" value={formatSpeed(avgSpeedBytesPerSec)} />
                <Dot />
                {/* A dash until a speed has been held long enough to call it the peak. */}
                <InlineStat
                  label="PEAK"
                  value={
                    peakSpeedBytesPerSec === undefined ? '—' : formatSpeed(peakSpeedBytesPerSec)
                  }
                />
              </div>
              {isPaused || waiting
                ? (download.error || waiting) && (
                    <div
                      role="alert"
                      className="mt-0.5 font-sans text-[11px] leading-[1.2] font-medium text-destructive"
                    >
                      {download.error ? describeError(download.error) : waiting}
                    </div>
                  )
                : activeChipOption && (
                    <CyclableChip
                      label={activeChipOption.label}
                      tooltip={`${activeChipOption.tooltip}${chipOptions.length > 1 ? ' (click to toggle)' : ''}`}
                      bg={activeChipOption.visual.bg}
                      border={activeChipOption.visual.border}
                      color={activeChipOption.visual.text}
                      cyclable={chipOptions.length > 1}
                      onClick={() => setChipModeIndex((i) => (i + 1) % chipOptions.length)}
                    />
                  )}
            </>
          </div>

          <div
            className={`ml-auto min-w-0 max-w-[640px] flex-1 transition-opacity duration-200 ${
              isPaused ? 'opacity-45' : 'opacity-100'
            }`}
          >
            <div className="font-mono text-[9.5px] leading-none font-medium tracking-[0.12em] text-muted-foreground">
              THROUGHPUT{throughputStatusLabel ? ` · ${throughputStatusLabel}` : ''}
            </div>
            <ThroughputChart
              order={groups.map((g, i) => ({
                interfaceId: g.id,
                solid: visuals[i].solid,
                name: visuals[i].name
              }))}
              historyByInterface={speedHistory}
              endsAt={isPaused ? 'pause' : 'now'}
            />
          </div>
        </div>
      </HeroBand>

      {/* File info — always visible, never shrinks */}
      <div className="shrink-0 p-[16px_20px_0px]">
        <div className="flex items-center gap-[14px]">
          <div className="flex size-11 shrink-0 items-center justify-center rounded-[10px] border-[0.5px] border-[var(--border-strong)] bg-card font-mono text-[10.5px] leading-none font-bold tracking-[0.04em] text-[var(--text-secondary)]">
            {isFolder(download) ? (
              <Folder aria-label="Folder" className="size-[18px]" />
            ) : (
              fileExtensionBadge(download.fileName)
            )}
          </div>
          <div className="flex min-w-0 flex-1 flex-col gap-1.5">
            <div className="flex min-w-0 items-center gap-2">
              <TruncatedText
                text={download.fileName}
                className="font-sans text-[15px] leading-[1.3] font-semibold tracking-[-0.01em] text-foreground"
              />
              {isTorrent && <TorrentBadge />}
              {download.kind === 'nzb' && <UsenetBadge />}
            </div>
            <div className="flex min-w-0 items-center gap-[7px] font-mono text-[12.5px] leading-[1.2] tabular-nums text-[var(--text-secondary)]">
              <span>
                {formatBytes(download.bytesDownloaded)}
                {knownSize ? ` of ${formatBytes(wantedBytes(download))}` : ''}
              </span>
              {knownSize && (
                <>
                  <Dot />
                  <span className="font-semibold text-foreground">{percent}%</span>
                </>
              )}
              {isTorrent && (
                <>
                  <Dot />
                  <span>
                    {download.peers.length} {download.peers.length === 1 ? 'peer' : 'peers'}
                  </span>
                </>
              )}
              {download.kind === 'nzb' && (
                <>
                  <Dot />
                  <span>
                    {describeFileCount(download.nzbFiles.length, download.nzbFiles.length)}
                  </span>
                  <Dot />
                  <UsenetServerButton host={download.server} />
                </>
              )}
              {missingArticles > 0 && (
                <>
                  <Dot />
                  <Tooltip>
                    <TooltipTrigger
                      render={
                        <span tabIndex={0} className="text-destructive outline-none">
                          {missingArticles} missing
                        </span>
                      }
                    />
                    <TooltipContent>
                      The news server doesn’t have{' '}
                      {missingArticles === 1 ? 'this article' : 'these articles'}. Once the download
                      is done, Plexo repairs its files with their .par2 files, if par2 is installed.
                    </TooltipContent>
                  </Tooltip>
                </>
              )}
              {download.kind === 'nzb' && !!download.fromBackup && (
                <>
                  <Dot />
                  <span>{download.fromBackup} from backup</span>
                </>
              )}
              {download.kind === 'nzb' && download.backupError && (
                <>
                  <Dot />
                  <Tooltip>
                    <TooltipTrigger
                      render={
                        <span tabIndex={0} className="text-destructive outline-none">
                          backup server error
                        </span>
                      }
                    />
                    <TooltipContent>{download.backupError}</TooltipContent>
                  </Tooltip>
                </>
              )}
              {download.kind === 'nzb' && download.postProcess?.stage && !isPaused && (
                <>
                  <Dot />
                  <span role="status" className="text-foreground">
                    {STAGE_LABELS[download.postProcess.stage]}
                    {download.postProcess.percent !== undefined &&
                      ` ${download.postProcess.percent}%`}
                  </span>
                </>
              )}
              {/* Several files: they open below. One is the name above. */}
              {download.kind === 'torrent' && download.files.total > 1 && (
                <>
                  <Dot />
                  <Button
                    type="button"
                    variant="outline"
                    size="xs"
                    onClick={() => setFilesOpen((open) => !open)}
                    aria-expanded={filesOpen}
                    className="h-auto cursor-default rounded-[4px] border-[0.5px] bg-card px-[7px] py-[3px] font-mono text-[10.5px] leading-none font-medium text-[var(--text-secondary)] aria-expanded:bg-secondary dark:bg-card"
                  >
                    {describeFileCount(download.files.chosen, download.files.total)}{' '}
                    <span aria-hidden className="text-[7.5px] opacity-75">
                      {filesOpen ? '▲' : '▼'}
                    </span>
                  </Button>
                </>
              )}
              {download.kind === 'torrent' && (
                <>
                  <Dot />
                  <Button
                    type="button"
                    variant="outline"
                    size="xs"
                    onClick={() => void perform('trackers', [download])}
                    className="h-auto cursor-default rounded-[4px] border-[0.5px] bg-card px-[7px] py-[3px] font-mono text-[10.5px] leading-none font-medium text-[var(--text-secondary)] hover:bg-secondary dark:bg-card"
                  >
                    Trackers
                  </Button>
                </>
              )}
              {!isPaused && download.timeLeftSeconds !== undefined && (
                <>
                  <Dot />
                  <span className="text-[var(--text-secondary)]">
                    {formatEta(download.timeLeftSeconds)} left
                  </span>
                </>
              )}
              {statusBadge && (
                <ColorBadge
                  bg={statusBadge.palette.bg}
                  border={statusBadge.palette.border}
                  text={statusBadge.palette.text}
                  // Pinned for the same reason as the stream row's ACTIVE badge: sizing itself,
                  // it pushed this text block past the 44px file-type icon beside it and nudged
                  // everything below down. At h-4 the block stays under the icon, so the row
                  // height is the icon's either way.
                  className="h-4 rounded-[3.5px] px-[7px] py-0.5 text-[9.5px] font-semibold tracking-[0.08em]"
                >
                  {statusBadge.label}
                </ColorBadge>
              )}
              {totalRetries > 0 && (
                <>
                  <Dot />
                  <span className="text-[var(--color-usb)]">
                    {totalRetries} {totalRetries === 1 ? 'retry' : 'retries'}
                  </span>
                </>
              )}
              {/* Last and to the right: the one part that gives way when the line runs short. */}
              <Tooltip>
                <TooltipTrigger
                  render={
                    <span className="ml-auto flex min-w-0 items-center gap-1.5 pl-3 text-[11px] text-muted-foreground">
                      <Folder aria-hidden className="size-3 shrink-0" />
                      <span className="sr-only">Saving to</span>
                      <span className="truncate">
                        {toDisplayPath(dirnameOf(download.destinationPath), homeDir)}
                      </span>
                    </span>
                  }
                />
                <TooltipContent>Saving to: {download.destinationPath}</TooltipContent>
              </Tooltip>
            </div>
          </div>
        </div>
        {download.kind === 'torrent' && filesOpen && (
          <TorrentFiles
            downloadId={download.id}
            pieces={download.pieces}
            selected={download.files.selected}
          />
        )}
      </div>

      {/* Block grid: pinned with the file info. It's capped in height and scrolls itself. */}
      <div className="shrink-0 px-5 pt-3">
        <BlockGrid
          blocks={download.kind === 'torrent' ? download.pieces : download.blocks}
          groups={groups}
          visuals={visuals}
          knownSize={knownSize}
          remainingBytes={remainingBytes}
          isPaused={isPaused}
          pieces={isTorrent}
          articles={download.kind === 'nzb'}
        />
      </div>

      {/* Network table: only its rows scroll, under their column headers. Edge to edge: its rows
          pad themselves. */}
      <div className="flex min-h-0 flex-1 flex-col overflow-y-auto pb-2">
        <div className="mt-3">
          <div
            role="table"
            aria-label="Networks"
            className="grid gap-x-3"
            style={{ gridTemplateColumns: NETWORK_ROW_GRID_COLUMNS }}
          >
            <div
              role="row"
              className="sticky top-0 z-10 col-span-full grid grid-cols-subgrid gap-x-3 border-b border-border bg-background pt-2.5 pb-[7px] font-mono text-[9.5px] leading-none tracking-[0.12em] text-muted-foreground uppercase"
            >
              <div role="columnheader" aria-label="Status" />
              <div role="columnheader">Network</div>
              <div role="columnheader">
                {isTorrent ? (
                  <Tooltip>
                    <TooltipTrigger
                      render={
                        <button
                          type="button"
                          className="rounded-sm text-inherit uppercase focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
                        >
                          Progress
                        </button>
                      }
                    />
                    <TooltipContent>
                      Percentage of the download completed with verified data from this network.
                    </TooltipContent>
                  </Tooltip>
                ) : (
                  'Progress'
                )}
              </div>
              <div role="columnheader" className="text-right">
                Share
              </div>
              <div role="columnheader" className="text-right">
                Speed
              </div>
              <div role="columnheader" className="pr-5 text-right">
                {isTorrent ? 'Transferred' : 'Downloaded'}
              </div>
            </div>
            {rows.map((row, index) => (
              <NetworkRow
                key={row.id}
                group={row}
                visual={rowVisuals[index]}
                sharePercent={
                  totalDownloadedByNetworks > 0
                    ? (row.bytesDownloaded / totalDownloadedByNetworks) * 100
                    : 0
                }
                totalBytes={wantedBytes(download)}
                blocks={download.kind === 'torrent' ? undefined : download.blocks}
                usenet={download.kind === 'nzb'}
                onSwitch={(enabled) =>
                  void window.plexo.setDownloadNetwork(download.id, row.id, enabled)
                }
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
})
