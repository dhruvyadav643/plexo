import { applyDownloadUpdate } from '@shared/downloadUpdate'
import { carryOverDevicePreferences } from '@shared/networkPreferences'
import { sameProxyEndpoint } from '@shared/proxy'
import type {
  AppSettings,
  DownloadSchedule,
  DownloadState,
  DownloadUpdate,
  FinishedDownload,
  NetworkInterfaceInfo,
  NetworkPreference,
  NetworkPreferences,
  PendingLink,
  ProxyConfig,
  SpeedUnit,
  ThemeSource
} from '@shared/types'
import { create } from 'zustand'

export type DownloadFilter = 'all' | 'progress' | 'finished' | 'failed'

type LoadStatus = 'idle' | 'loading' | 'ready' | 'error'

/** What the window shows: the list of downloads, or one download. */
export type View = { name: 'list' } | { name: 'download'; id: string }

interface AppStore {
  interfaces: NetworkInterfaceInfo[]
  interfacesStatus: LoadStatus
  interfacesError: string | null
  /** User customizations (name/color) per network interface id — persisted in the main process. */
  networkPreferences: NetworkPreferences
  /** A proxy password typed is kept only until Plexo quits: there's no keychain to seal it with. */
  noKeychain: boolean

  /** Persisted in the main process alongside nativeTheme.themeSource. */
  themeSource: ThemeSource

  homeDir: string
  downloadsDir: string

  /** Every download that isn't finished, by id — running, queued, paused or failed. */
  downloads: Record<string, DownloadState>
  /** Finished downloads, newest first (see main/download/history.ts). */
  history: FinishedDownload[]
  view: View
  downloadFilter: DownloadFilter
  setDownloadFilter: (filter: DownloadFilter) => void
  downloadSchedule: DownloadSchedule | undefined
  /** The New download dialog, over whatever the window shows. */
  newDownloadOpen: boolean
  /** The Telegram dialog: sign-in, then the Saved Messages media browser. */
  telegramOpen: boolean
  openTelegram: () => void
  closeTelegram: () => void
  /** Persisted — how many downloads run at once; the rest wait in the queue. */
  downloadsAtOnce: number
  /** Persisted — the speed limits (see AppSettings). */
  speedLimit: number | undefined
  slowMode: boolean
  slowModeSpeed: number
  /** Persisted — MB/s or Mbps, for every speed shown. */
  speedUnit: SpeedUnit

  /** Lifted out of the Idle screen so it survives a swap to/from the No-connections screen. */
  draftUrl: string
  /** Handed-over links stacked in New download, oldest first. */
  links: PendingLink[]
  /** Null while New download shows a link typed or pasted there instead. Links are named by
   * id, never by position: the list changes while a start is under way. */
  shownId: string | null
  /** Bumped to remount New download's form for another link. */
  formKey: number
  /** The link last started: still on the clipboard afterwards, so not offered again. */
  startedUrl: string
  /** Persisted — the last folder picked, falling back to downloadsDir. */
  destinationDir: string

  /** Asks the main process for the network list now; it also pushes every change. */
  loadInterfaces: () => Promise<void>
  receiveInterfaces: (interfaces: NetworkInterfaceInfo[]) => void
  setNetworkPreference: (id: string, patch: NetworkPreference) => void
  setThemeSource: (source: ThemeSource) => void
  /** A snapshot or an update of a download, from the main process. */
  receiveDownloadUpdate: (update: DownloadUpdate) => void
  /** Finished downloads as main lists them; any that finished leave `downloads`. */
  receiveHistory: (history: FinishedDownload[]) => void
  /** Drops a download from the window's view once the main process has removed it. */
  forgetDownload: (id: string) => void
  setView: (view: View) => void
  /** Opens New download, with `link` in its link field when one is given. */
  openNewDownload: (link?: string) => void
  closeNewDownload: () => void
  receiveLinks: () => Promise<void>
  showLink: (id: string) => void
  /** If it was the one shown, the newest left is shown, or New download closes. */
  finishLink: (id: string, started: boolean) => void
  /** Leaves what New download shows alone, the typed link included. */
  dropLink: (id: string, started: boolean) => void
  setDownloadsAtOnce: (count: number) => void
  /** Each one applies at once, to every download (see main/network/limits.ts). */
  setSpeedLimit: (bytesPerSec: number | undefined) => void
  setSlowMode: (on: boolean) => void
  setSlowModeSpeed: (bytesPerSec: number) => void
  setSpeedUnit: (unit: SpeedUnit) => void
  /** Pinned default destination folder. When set, new downloads start here rather than
   * remembering one-off folder changes. */
  defaultDestinationDir?: string
  settingsOpen: boolean
  settingsPage: string | null
  settingsShowSchedule: boolean
  openSettings: (page?: string | null, showSchedule?: boolean) => void
  closeSettings: () => void
  setSettingsPage: (page: string | null) => void
  setDraftUrl: (url: string) => void
  setDestinationDir: (dir: string) => void
  setDefaultDestinationDir: (dir?: string) => void
}

// Settings saved by the main process, read once before the first paint (see InitialState).
const initial = window.plexo.initialState

/** Every setting changes optimistically: the store is updated first so the UI feels instant,
 * then this saves it. The store stays the source of truth either way — a failed save just means
 * the change isn't remembered next launch. */
function persist(patch: AppSettings): void {
  window.plexo.updateSettings(patch).catch(() => {})
}

/** A proxy as the window keeps it once saved: whether it has a password, not the password. None
 * sent keeps the one it had, if main kept it: for the same proxy and username only. */
function withoutPassword({ password, ...proxy }: ProxyConfig, had: boolean): ProxyConfig {
  return { ...proxy, hasPassword: password === undefined ? had : password !== '' }
}

/** Links let go here: a listing main sent before it heard so would bring them back. */
const letGo = new Set<string>()

export const useAppStore = create<AppStore>((set, get) => ({
  interfaces: [],
  interfacesStatus: 'idle',
  interfacesError: null,
  networkPreferences: initial.networkPreferences,
  noKeychain: initial.noKeychain === true,
  themeSource: initial.themeSource,

  homeDir: initial.homeDir,
  downloadsDir: initial.downloadsDir,

  downloads: {},
  history: [],
  view: { name: 'list' },
  downloadFilter: 'all',
  setDownloadFilter: (downloadFilter) => set({ downloadFilter }),
  downloadSchedule: initial.downloadSchedule,
  newDownloadOpen: false,
  telegramOpen: false,
  openTelegram: () => set({ telegramOpen: true }),
  closeTelegram: () => set({ telegramOpen: false }),
  settingsOpen: false,
  settingsPage: null,
  settingsShowSchedule: false,
  openSettings: (page = null, showSchedule = false) =>
    set({ settingsOpen: true, settingsPage: page, settingsShowSchedule: showSchedule }),
  closeSettings: () => set({ settingsOpen: false }),
  setSettingsPage: (settingsPage) => set({ settingsPage }),
  downloadsAtOnce: initial.downloadsAtOnce,
  speedLimit: initial.speedLimit,
  slowMode: initial.slowMode,
  slowModeSpeed: initial.slowModeSpeed,
  speedUnit: initial.speedUnit,

  draftUrl: '',
  links: [],
  shownId: null,
  formKey: 0,
  startedUrl: '',
  defaultDestinationDir: initial.defaultDestinationDir,
  // Main has already checked this folder exists. Never fall back to the raw pinned setting here:
  // it may point to a removed drive, while destinationDir has safely fallen back to Downloads.
  destinationDir: initial.destinationDir ?? initial.downloadsDir,

  loadInterfaces: async () => {
    // A re-scan keeps showing the last result rather than flashing back to 'loading'.
    if (get().interfacesStatus !== 'ready') set({ interfacesStatus: 'loading' })
    set({ interfacesError: null })
    try {
      get().receiveInterfaces(await window.plexo.listInterfaces())
    } catch (error) {
      set({
        interfacesStatus: 'error',
        interfacesError: error instanceof Error ? error.message : String(error)
      })
    }
  },

  receiveInterfaces: (interfaces) => {
    set({ interfaces, interfacesStatus: 'ready', interfacesError: null })
    // Main moves them too, with no window open; this copy is what the window saves whole.
    const saved = get().networkPreferences
    const networkPreferences = carryOverDevicePreferences(saved, interfaces)
    if (networkPreferences !== saved) {
      set({ networkPreferences })
      persist({ networkPreferences })
    }
  },

  // An explicit `undefined` in `patch` clears that field; main drops an entry left with neither.
  setNetworkPreference: (id, patch) => {
    const preferences = get().networkPreferences
    const preference = { ...preferences[id], ...patch }
    // A proxy password goes to main, which seals it: the window keeps only that there is one, so
    // what it sends next, with no password, keeps it.
    const before = preferences[id]?.proxy
    const had =
      before?.hasPassword === true &&
      preference.proxy !== undefined &&
      sameProxyEndpoint(before, preference.proxy)
    const shown = preference.proxy
      ? { ...preference, proxy: withoutPassword(preference.proxy, had) }
      : preference
    set({ networkPreferences: { ...preferences, [id]: shown } })
    persist({ networkPreferences: { ...preferences, [id]: preference } })
  },

  setThemeSource: (themeSource) => {
    set({ themeSource })
    persist({ themeSource })
  },

  receiveDownloadUpdate: (update) => {
    const { downloads, history } = get()
    // Finished already: an update that arrives late mustn't bring it back.
    if (history.some((entry) => entry.id === update.state.id)) return
    const previous = downloads[update.state.id] ?? null
    const download = applyDownloadUpdate(previous, update)
    if (!download || download === previous) return
    set({ downloads: { ...downloads, [download.id]: download } })
  },

  receiveHistory: (history) => {
    const downloads = { ...get().downloads }
    for (const entry of history) delete downloads[entry.id]
    set({ history, downloads })
  },

  forgetDownload: (id) => {
    const { [id]: removed, ...downloads } = get().downloads
    void removed
    set({ downloads, history: get().history.filter((entry) => entry.id !== id) })
  },

  setView: (view) => set({ view }),

  openNewDownload: (link) =>
    set((state) => ({
      newDownloadOpen: true,
      formKey: state.formKey + 1,
      ...(link === undefined ? {} : { draftUrl: link })
    })),

  closeNewDownload: () => {
    const { links, shownId } = get()
    if (shownId) return get().finishLink(shownId, false)
    if (links.length > 0) return get().showLink(links[links.length - 1].id)
    set({ newDownloadOpen: false })
  },

  receiveLinks: async () => {
    // main lists every link still waiting, so a window that was closed or reloaded gets them back.
    const pending = await window.plexo.pendingLinks().catch(() => [])
    const known = new Set(get().links.map((link) => link.id))
    const arrived = pending.filter((link) => !known.has(link.id) && !letGo.has(link.id))
    if (arrived.length === 0) return
    set({ links: [...get().links, ...arrived], newDownloadOpen: true })
    get().showLink(arrived[arrived.length - 1].id)
  },

  showLink: (id) => {
    const link = get().links.find((candidate) => candidate.id === id)
    if (link) set({ shownId: id, draftUrl: link.url, formKey: get().formKey + 1 })
  },

  finishLink: (id, started) => {
    const wasShown = get().shownId === id
    get().dropLink(id, started)
    if (!wasShown) return
    const left = get().links
    set({ draftUrl: '' })
    if (left.length > 0) get().showLink(left[left.length - 1].id)
    else set({ newDownloadOpen: false })
  },

  dropLink: (id, started) => {
    const { links, shownId } = get()
    if (!links.some((link) => link.id === id)) return
    letGo.add(id)
    // Started, main has already forgotten its sign-in.
    if (!started) void window.plexo.dismissLink(id).catch(() => {})
    set({
      links: links.filter((link) => link.id !== id),
      ...(shownId === id && { shownId: null })
    })
  },

  setDownloadsAtOnce: (downloadsAtOnce) => {
    set({ downloadsAtOnce })
    persist({ downloadsAtOnce })
  },

  setSpeedLimit: (speedLimit) => {
    set({ speedLimit })
    persist({ speedLimit })
  },

  setSlowMode: (slowMode) => {
    set({ slowMode })
    persist({ slowMode })
  },

  setSlowModeSpeed: (slowModeSpeed) => {
    set({ slowModeSpeed })
    persist({ slowModeSpeed })
  },

  setSpeedUnit: (speedUnit) => {
    set({ speedUnit })
    persist({ speedUnit })
  },

  setDraftUrl: (draftUrl) => set({ draftUrl }),
  setDestinationDir: (destinationDir) => {
    set({ destinationDir })
    if (!get().defaultDestinationDir) {
      persist({ destinationDir })
    }
  },
  setDefaultDestinationDir: (defaultDestinationDir) => {
    set({
      defaultDestinationDir,
      destinationDir: defaultDestinationDir ?? get().downloadsDir
    })
    persist({ defaultDestinationDir })
  }
}))
