import { contextBridge, ipcRenderer, webUtils, type IpcRendererEvent } from 'electron'
import { IpcChannels } from '../shared/ipc-channels'
import type { IpcContract } from '../shared/ipc-contract'
import type {
  AppSettings,
  DownloadUpdate,
  InitialState,
  MagnetCheckStatus,
  NetworkInterfaceInfo,
  TelegramAuthState,
  TelegramCredentials,
  UpdateState,
  UsenetServerInput
} from '../shared/types'

/** Typed wrapper around ipcRenderer.invoke — the channel name picks its args/result shape out of
 * IpcContract, so a call here that doesn't match what registerIpcHandlers (main) actually handles
 * is a compile error instead of a silent runtime mismatch. */
function invoke<K extends keyof IpcContract>(
  channel: K,
  ...args: IpcContract[K]['args']
): Promise<IpcContract[K]['result']> {
  return ipcRenderer.invoke(IpcChannels[channel], ...args)
}

const plexoApi = {
  platform: process.platform,
  // Sync on purpose — see InitialState. One small read, once, before the renderer's first paint.
  initialState: ipcRenderer.sendSync(IpcChannels.getInitialState) as InitialState,

  listInterfaces: () => invoke('listInterfaces'),
  deviceBindingSupported: () => invoke('deviceBindingSupported'),
  openNetworkSettings: () => invoke('openNetworkSettings'),
  updateSettings: (patch: AppSettings) => invoke('updateSettings', patch),
  probeUrl: (url: string) => invoke('probeUrl', url),
  chooseDestinationFolder: (defaultPath: string) => invoke('chooseDestinationFolder', defaultPath),
  chooseDownloadFile: () => invoke('chooseDownloadFile'),
  /** Where a file dropped on the window is on disk ('' for one that isn't a file). */
  pathForFile: (file: File) => webUtils.getPathForFile(file),
  readClipboardText: () => invoke('readClipboardText'),
  revealDownload: (id: string) => invoke('revealDownload', id),
  openDownload: (id: string) => invoke('openDownload', id),
  startDownload: (request: IpcContract['startDownload']['args'][0], linkId?: string) =>
    invoke('startDownload', request, linkId),
  listDownloads: () => invoke('listDownloads'),
  listHistory: () => invoke('listHistory'),
  clearHistory: () => invoke('clearHistory'),
  networkUsage: () => invoke('networkUsage'),
  resetNetworkUsage: (id) => invoke('resetNetworkUsage', id),
  freeSpace: (dir: string) => invoke('freeSpace', dir),
  torrentFiles: (downloadId: string) => invoke('torrentFiles', downloadId),
  chooseTorrentFiles: (downloadId: string, selected: number[]) =>
    invoke('chooseTorrentFiles', downloadId, selected),
  torrentTrackers: (downloadId: string) => invoke('torrentTrackers', downloadId),
  addTorrentTrackers: (downloadId: string, trackers: string[]) =>
    invoke('addTorrentTrackers', downloadId, trackers),
  pauseDownload: (downloadId: string) => invoke('pauseDownload', downloadId),
  resumeDownload: (downloadId: string) => invoke('resumeDownload', downloadId),
  startNext: (downloadId: string) => invoke('startNext', downloadId),
  relinkDownload: (downloadId: string, url: string) => invoke('relinkDownload', downloadId, url),
  setDownloadNetwork: (downloadId: string, networkId: string, enabled: boolean) =>
    invoke('setDownloadNetwork', downloadId, networkId, enabled),
  cancelDownload: (downloadId: string) => invoke('cancelDownload', downloadId),
  removeDownload: (downloadId: string, options?: { trashFile?: boolean }) =>
    invoke('removeDownload', downloadId, options),
  updateState: () => invoke('updateState'),
  showUpdateMenu: () => invoke('showUpdateMenu'),
  pendingLinks: () => invoke('pendingLinks'),
  resumeFromLink: (linkId: string, downloadId: string) =>
    invoke('resumeFromLink', linkId, downloadId),
  dismissLink: (id: string) => invoke('dismissLink', id),
  usenetServer: () => invoke('usenetServer'),
  saveUsenetServer: (server: UsenetServerInput) => invoke('saveUsenetServer', server),
  saveUsenetBackup: (server: UsenetServerInput | null) => invoke('saveUsenetBackup', server),
  testUsenetServer: (server: UsenetServerInput, backup?: boolean) =>
    invoke('testUsenetServer', server, backup),

  telegramState: () => invoke('telegramState'),
  telegramStartLogin: (credentials: TelegramCredentials) =>
    invoke('telegramStartLogin', credentials),
  telegramStartQrLogin: () => invoke('telegramStartQrLogin'),
  telegramSubmitCode: (code: string) => invoke('telegramSubmitCode', code),
  telegramSubmitPassword: (password: string) => invoke('telegramSubmitPassword', password),
  telegramLogout: () => invoke('telegramLogout'),
  telegramListMedia: (offsetId?: number, limit?: number) =>
    invoke('telegramListMedia', offsetId, limit),

  /** Where Telegram sign-in stands changed (see TelegramAuthState). */
  onTelegramAuth: (callback: (state: TelegramAuthState) => void): (() => void) => {
    const listener = (_event: IpcRendererEvent, state: TelegramAuthState): void => callback(state)
    ipcRenderer.on(IpcChannels.telegramAuthChanged, listener)
    return () => ipcRenderer.removeListener(IpcChannels.telegramAuthChanged, listener)
  },

  /** pendingLinks() has the new link. */
  onLinkReceived: (callback: () => void): (() => void) => {
    const listener = (): void => callback()
    ipcRenderer.on(IpcChannels.linkReceived, listener)
    return () => ipcRenderer.removeListener(IpcChannels.linkReceived, listener)
  },

  onDownloadUpdated: (callback: (update: DownloadUpdate) => void): (() => void) => {
    const listener = (_event: IpcRendererEvent, update: DownloadUpdate): void => callback(update)
    ipcRenderer.on(IpcChannels.downloadUpdated, listener)
    return () => ipcRenderer.removeListener(IpcChannels.downloadUpdated, listener)
  },

  /** A download was added to the finished ones or forgotten: listHistory() has them. */
  onHistoryChanged: (callback: () => void): (() => void) => {
    const listener = (): void => callback()
    ipcRenderer.on(IpcChannels.historyChanged, listener)
    return () => ipcRenderer.removeListener(IpcChannels.historyChanged, listener)
  },

  onUpdateState: (callback: (state: UpdateState) => void): (() => void) => {
    const listener = (_event: IpcRendererEvent, state: UpdateState): void => callback(state)
    ipcRenderer.on(IpcChannels.updateStateChanged, listener)
    return () => ipcRenderer.removeListener(IpcChannels.updateStateChanged, listener)
  },

  onNetworksChanged: (callback: (networks: NetworkInterfaceInfo[]) => void): (() => void) => {
    const listener = (_event: IpcRendererEvent, networks: NetworkInterfaceInfo[]): void =>
      callback(networks)
    ipcRenderer.on(IpcChannels.networksChanged, listener)
    return () => ipcRenderer.removeListener(IpcChannels.networksChanged, listener)
  },

  onMagnetCheckStatus: (callback: (status: MagnetCheckStatus) => void): (() => void) => {
    const listener = (_event: IpcRendererEvent, status: MagnetCheckStatus): void => callback(status)
    ipcRenderer.on(IpcChannels.magnetCheckStatus, listener)
    return () => ipcRenderer.removeListener(IpcChannels.magnetCheckStatus, listener)
  }
}

export type PlexoApi = typeof plexoApi

// Nothing in the renderer needs raw Electron/Node access — only the typed plexoApi above is
// exposed. The @electron-toolkit/preload electronAPI (which hands the renderer an unrestricted
// ipcRenderer.invoke/send/on on any channel) is deliberately not bridged.
if (process.contextIsolated) {
  try {
    contextBridge.exposeInMainWorld('plexo', plexoApi)
  } catch (error) {
    console.error(error)
  }
} else {
  // @ts-ignore (define in dts)
  window.plexo = plexoApi
}
