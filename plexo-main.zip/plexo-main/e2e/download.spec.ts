import { BLOCK, expect, LAN_ADDRESS, test } from './fixtures'

// A. Downloads that should simply work. Every test also runs the automatic checks in
// fixtures.ts: completed ⇒ the file's SHA-256 matches the source, nothing stray left behind.

test.describe('happy paths @smoke', () => {
  test('IPv6-only origin downloads through an IPv6 interface', async ({ plexo, serve }) => {
    const origin = await serve({ size: 4 * BLOCK, host: '::1' })
    await plexo.relaunch({ PLEXO_E2E_INTERFACES: 'a=::1' })
    await plexo.start(origin.url(), origin.sha256)
    const state = await plexo.waitForHttpStatus('completed')
    expect(state.networks.every((network) => network.retries === 0)).toBe(true)
    expect(origin.chunkRequests().every((request) => request.from === '::1')).toBe(true)
  })

  test('IPv6 origin reports an incompatible IPv4-only selection immediately', async ({
    plexo,
    serve
  }) => {
    const origin = await serve({ size: BLOCK, host: '::1' })
    await expect(plexo.start(origin.url(), origin.sha256)).rejects.toThrow(/No selected network/)
    expect(await plexo.currentHttp()).toBeNull()
  })

  for (const [label, size] of [
    ['1 byte', 1],
    ['37.5 blocks', Math.floor(BLOCK * 37.5)]
  ] as const) {
    test(`ranged download: ${label}`, async ({ plexo, serve }) => {
      const origin = await serve({ size })
      await plexo.start(origin.url(), origin.sha256, { connections: 4 })
      const state = await plexo.waitForHttpStatus('completed')
      expect(state.bytesDownloaded).toBe(size)
      expect(state.totalBlocks).toBe(Math.ceil(size / BLOCK))
    })
  }

  test('each stream keeps its connection from one block to the next', async ({ plexo, serve }) => {
    const origin = await serve({ size: 20 * BLOCK + 123 })
    await plexo.start(origin.url(), origin.sha256, { connections: 4 })
    const state = await plexo.waitForHttpStatus('completed')
    expect(state.streams).toHaveLength(4)
    const requests = origin.chunkRequests()
    expect(new Set(requests.map((request) => request.connection)).size).toBe(4)
    expect(requests.length).toBeGreaterThan(4)
  })

  test('two networks share the work, and attribution matches what the server saw', async ({
    plexo,
    serve
  }) => {
    test.skip(!LAN_ADDRESS, 'needs a LAN address to act as the second network')
    const origin = await serve({ size: 40 * BLOCK })
    await plexo.start(origin.url(), origin.sha256, { networks: ['a', 'b'], connections: 2 })
    const state = await plexo.waitForHttpStatus('completed')

    const served = { a: 0, b: 0 }
    for (const entry of origin.chunkRequests()) {
      served[entry.from === '127.0.0.1' ? 'a' : 'b'] += entry.bytesSent
    }
    const attributed = { a: 0, b: 0 }
    for (const block of state.blocks ?? []) {
      attributed.a += block.bytesByInterface['a'] ?? 0
      attributed.b += block.bytesByInterface['b'] ?? 0
    }
    expect(served.a, 'network a carried some of the file').toBeGreaterThan(0)
    expect(served.b, 'network b carried some of the file').toBeGreaterThan(0)
    expect(attributed).toEqual(served)
  })

  test('after the first, updates carry only the blocks that changed', async ({ plexo, serve }) => {
    const origin = await serve({ size: 64 * BLOCK, bytesPerSecond: 500_000 })
    const id = await plexo.start(origin.url(), origin.sha256)
    await plexo.waitForHttpStatus('completed')
    const sent = plexo.updates
      .at(-1)!
      .filter((update) => update.state.id === id && 'blocks' in update)
      .filter(
        (update): update is import('../src/shared/types').HttpDownloadUpdate => 'blocks' in update
      )
    expect(sent.length, 'progress kept coming while it downloaded').toBeGreaterThan(5)
    expect(sent[0].blocks).toHaveLength(64)
    // Two streams move a few blocks between one update and the next, not all 64.
    expect(Math.max(...sent.slice(1).map((update) => update.blocks.length))).toBeLessThan(16)
  })

  test('server without range support: one stream, whole file', async ({ plexo, serve }) => {
    const origin = await serve({ size: 10 * BLOCK, ranges: false })
    await plexo.start(origin.url(), origin.sha256)
    const state = await plexo.waitForHttpStatus('completed')
    expect(state.streams).toHaveLength(1)
  })

  test('server that refuses range requests with 403: one stream, whole file', async ({
    plexo,
    serve
  }) => {
    const origin = await serve({ size: 10 * BLOCK })
    origin.setRule(({ range }) => (range ? { status: 403 } : 'ok'))
    const probe = await plexo.api.probeUrl(origin.url())
    expect(probe).toMatchObject({ kind: 'http', supportsRanges: false, totalBytes: 10 * BLOCK })
    await plexo.start(origin.url(), origin.sha256)
    const state = await plexo.waitForHttpStatus('completed')
    expect(state.streams).toHaveLength(1)
    // After the probe's ranged GET, nothing else asks for a range the server would refuse.
    expect(origin.chunkRequests().filter((request) => request.range !== null)).toEqual([])
  })

  test('server that ignores the end of a range: one stream, whole file', async ({
    plexo,
    serve
  }) => {
    const origin = await serve({ size: 10 * BLOCK })
    origin.setRule(({ range }) => (range ? 'wholeRange' : 'ok'))
    const probe = await plexo.api.probeUrl(origin.url())
    expect(probe).toMatchObject({
      kind: 'http',
      supportsRanges: false,
      totalBytes: 10 * BLOCK
    })
    await plexo.start(origin.url(), origin.sha256)
    const state = await plexo.waitForHttpStatus('completed')
    expect(state.streams).toHaveLength(1)
    // The transfer asks for the whole file, not a range the server would overrun.
    expect(origin.chunkRequests().filter((request) => request.range !== null)).toEqual([])
  })

  test('server that names the file end but sends only the range: streams still split', async ({
    plexo,
    serve
  }) => {
    const origin = await serve({ size: 10 * BLOCK })
    // Cloudflare-fronted hosts: Content-Range ends at the file, Content-Length is the range.
    origin.setRule(({ range }) => (range ? 'rangeToEof' : 'ok'))
    const probe = await plexo.api.probeUrl(origin.url())
    expect(probe).toMatchObject({
      kind: 'http',
      supportsRanges: true,
      totalBytes: 10 * BLOCK
    })
    await plexo.start(origin.url(), origin.sha256, { connections: 2 })
    await plexo.waitForHttpStatus('completed')
    expect(
      origin.chunkRequests().filter((request) => request.range !== null).length
    ).toBeGreaterThan(0)
  })

  test('a link that answers 403 with or without a range is still an error', async ({
    plexo,
    serve
  }) => {
    const origin = await serve({ size: 3 * BLOCK })
    origin.setRule(() => ({ status: 403 }))
    await expect(plexo.api.probeUrl(origin.url())).rejects.toThrow(/status 403/)
  })

  test('unknown size (no Content-Length)', async ({ plexo, serve }) => {
    const origin = await serve({ size: 10 * BLOCK, ranges: false, contentLength: false })
    await plexo.start(origin.url(), origin.sha256)
    const state = await plexo.waitForHttpStatus('completed')
    expect(state.totalBytes).toBe(0)
  })

  test('redirect during probe and on chunk requests', async ({ plexo, serve }) => {
    const origin = await serve({ size: 12 * BLOCK })
    origin.setRule(({ path }) => (path === '/start' ? { redirect: '/files/test.bin' } : 'ok'))
    await plexo.start(origin.url('/start'), origin.sha256)
    await plexo.waitForHttpStatus('completed')

    // The chunk requests follow redirects too (a signed CDN URL rotating mid-download).
    const next = await serve({ size: 12 * BLOCK, seed: 7 })
    let redirected = 0
    next.setRule(({ path, range }) => {
      if (path === '/files/test.bin' && range && range.start > 0 && redirected++ < 3) {
        return { redirect: '/files/moved.bin' }
      }
      return 'ok'
    })
    await plexo.start(next.url(), next.sha256)
    await plexo.waitForHttpStatus('completed')
    expect(redirected).toBeGreaterThan(0)
  })
})

test.describe('file names @smoke', () => {
  const cases: [string, string, RegExp][] = [
    [
      'a quoted filename keeps priority over an earlier duplicate token',
      'attachment; filename=preview.csv; filename="quarterly report.csv"',
      /^quarterly report\.csv$/
    ],
    [
      'malformed earlier extended values do not hide a usable filename star',
      "attachment; filename*=not-extended; filename*=\"UTF-8''preview.csv\"; filename*=UTF-8''; filename*=UTF-8''report.csv",
      /^report\.csv$/
    ],
    [
      'a filename parameter accepts optional whitespace',
      'attachment; filename = "quarterly report.csv"',
      /^quarterly report\.csv$/
    ],
    [
      'an unrelated parameter does not shadow filename',
      'attachment; x-filename="preview.csv"; filename="quarterly report.csv"',
      /^quarterly report\.csv$/
    ],
    [
      'a quoted extension value does not shadow filename star',
      'attachment; note="filename*=UTF-8\'\'preview.csv"; filename="quarterly report.csv"',
      /^quarterly report\.csv$/
    ],
    [
      'an ordinary quoted filename is preserved',
      'attachment; filename="quarterly report.csv"',
      /^quarterly report\.csv$/
    ],
    [
      'a UTF-8 filename star is decoded',
      "attachment; filename*=UTF-8''caf%C3%A9.csv",
      /^café\.csv$/
    ],
    ['path traversal is flattened', 'attachment; filename="../../evil.sh"', /^\.\._\.\._evil\.sh$/],
    ['control characters are replaced', 'attachment; filename="a%0Ab.txt"', /^a_b\.txt$/],
    ['an empty quoted filename falls back to the link', 'attachment; filename=""', /^test\.bin$/],
    [
      'an unquoted filename keeps its spaces',
      'attachment; filename=quarterly report.csv; size=10',
      /^quarterly report\.csv$/
    ],
    [
      'an ISO-8859-1 filename* is decoded',
      "attachment; filename*=iso-8859-1'en'%A3%20rates.txt",
      /^£ rates\.txt$/
    ]
  ]
  for (const [label, disposition, expected] of cases) {
    test(label, async ({ plexo, serve, dirs }) => {
      const origin = await serve({ size: 3 * BLOCK, contentDisposition: disposition })
      await plexo.start(origin.url(), origin.sha256)
      const state = await plexo.waitForHttpStatus('completed')
      expect(state.fileName).toMatch(expected)
      expect(state.destinationPath.startsWith(dirs.dest)).toBe(true)
    })
  }

  test('the same name twice gets "(1)" and leaves the first file alone', async ({
    plexo,
    serve
  }) => {
    const first = await serve({ size: 3 * BLOCK, seed: 1 })
    await plexo.start(first.url(), first.sha256)
    const one = await plexo.waitForHttpStatus('completed')

    const second = await serve({ size: 5 * BLOCK, seed: 2 })
    await plexo.start(second.url(), second.sha256)
    const two = await plexo.waitForHttpStatus('completed')

    expect(one.fileName).toBe('test.bin')
    expect(two.fileName).toBe('test (1).bin')
    const { readFile } = await import('node:fs/promises')
    const { sha256 } = await import('./origin')
    expect(sha256(await readFile(one.destinationPath))).toBe(first.sha256)
  })
})

test.describe('edge cases', () => {
  test('a 0-byte file @smoke', async ({ plexo, serve }) => {
    const origin = await serve({ size: 0 })
    await plexo.start(origin.url(), origin.sha256)
    await plexo.waitForHttpStatus('completed', 5000)
  })

  test('a server that never answers the link check → an error, not endless "Checking…" @smoke', async ({
    plexo,
    serve
  }) => {
    const origin = await serve({ size: BLOCK })
    origin.setRule(() => 'stallHeaders')
    const started = Date.now()
    await expect(plexo.api.probeUrl(origin.url())).rejects.toThrow(/did not respond/)
    expect(Date.now() - started).toBeLessThan(10_000)
  })

  test('a link that expired mid-download carries on from a fresh one, not one to another file', async ({
    plexo,
    serve
  }) => {
    const origin = await serve({ size: 16 * BLOCK, seed: 7 })
    const held = origin.hold(4 * BLOCK)
    const id = await plexo.start(origin.url(), origin.sha256)
    await held
    origin.setRule(() => ({ status: 403 }))
    origin.release()
    const failed = await plexo.waitUntil((state) => state.status === 'error', 30_000)
    expect(failed.error).toMatch(/status 403/)
    const kept = failed.bytesDownloaded
    expect(kept).toBeGreaterThan(0)

    const other = await serve({ size: 8 * BLOCK, seed: 8 })
    await expect(plexo.api.relinkDownload(id, other.url())).rejects.toThrow(/different file/)
    // Same size and the same ETag (every test origin's "v1"), other bytes: labels alone would let
    // it through and mix two files.
    const lookalike = await serve({ size: 16 * BLOCK, seed: 9 })
    await expect(plexo.api.relinkDownload(id, lookalike.url())).rejects.toThrow(/different file/)

    const fresh = await serve({ size: 16 * BLOCK, seed: 7 })
    await plexo.api.relinkDownload(id, fresh.url())
    await plexo.waitForHttpStatus('completed')
    // Only what was missing came from the fresh link.
    const fetched = fresh.chunkRequests().reduce((sum, entry) => sum + entry.bytesSent, 0)
    expect(fetched).toBeLessThanOrEqual(16 * BLOCK - kept + 4 * BLOCK)
  })

  test('past two at once, downloads wait in the queue and start as room frees @smoke', async ({
    plexo,
    serve
  }) => {
    const origins = await Promise.all([1, 2, 3].map((seed) => serve({ size: 4 * BLOCK, seed })))
    const held = origins.map((origin) => origin.hold(BLOCK))
    const ids: string[] = []
    for (const origin of origins) ids.push(await plexo.start(origin.url(), origin.sha256))
    await Promise.all(held.slice(0, 2))
    const status = async (index: number): Promise<string | undefined> =>
      (await plexo.byId(ids[index]))?.status
    expect(await status(2)).toBe('queued')

    // A pause makes room: the queued one starts.
    await plexo.api.pauseDownload(ids[0])
    await held[2]
    expect(await status(2)).toBe('downloading')
    // Resumed while two run, it waits, first in line, for the next to finish.
    await plexo.api.resumeDownload(ids[0])
    await expect.poll(() => status(0)).toBe('queued')
    origins[1].release()
    await expect.poll(() => status(1)).toBe('completed')
    await expect.poll(() => status(0)).not.toBe('queued')

    for (const origin of origins) origin.release()
    for (let index = 0; index < 3; index++) {
      await expect.poll(() => status(index), { timeout: 20_000 }).toBe('completed')
    }
  })
})
